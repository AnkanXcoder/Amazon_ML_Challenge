"""Attach only provided normalized target/query text to final pre-ML candidates."""
from __future__ import annotations
import argparse,logging,time
from pathlib import Path
from prepare import set_duckdb
from candidates import qs,KIND_COLUMNS
LOG=logging.getLogger(__name__)
def attach(work:Path,start:int,end:int,dest:Path)->int:
    q=work/'queries_records.parquet';t=work/'targets_records.parquet';cand=work/'candidates.parquet'
    col=','.join('c.hits_'+k for k in KIND_COLUMNS)
    sql=f"""
    COPY (SELECT c.qidx,c.tidx,c.rnk,c.support,{col},
       c.name_jaro,c.name_jaccard,c.address_jaccard,c.address_token_containment,c.number_overlap,
       q.entity_id AS qid,t.entity_id AS tid,q.country AS country,
       q.name AS qname,t.name AS tname,q.core AS qcore,t.core AS tcore,
       q.addr AS qaddr,t.addr AS taddr,q.nterms AS qnterms,t.nterms AS tnterms,
       q.aterms AS qaterms,t.aterms AS taterms,q.nums AS qnums,t.nums AS tnums,
       q.region AS qregion,t.region AS tregion
       FROM read_parquet({qs(cand)}) c JOIN read_parquet({qs(q)}) q ON c.qidx=q.idx
       JOIN read_parquet({qs(t)}) t ON c.tidx=t.idx
       WHERE c.qidx >= {int(start)} AND c.qidx < {int(end)}
    ) TO {qs(dest)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)
    """
    con=set_duckdb(work/'join.duckdb',work);now=time.time();con.execute(sql)
    n=con.execute(f'SELECT COUNT(*) FROM read_parquet({qs(dest)})').fetchone()[0];con.close()
    LOG.info('joined queries %d--%d %d pairs %.1fs',start,end,n,time.time()-now);return n
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True,type=Path)
    p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,default=1000000000)
    p.add_argument('--output',required=True,type=Path);a=p.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    attach(a.work,a.start,a.end,a.output)
