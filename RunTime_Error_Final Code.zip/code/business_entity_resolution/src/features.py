"""Fifty-six record-pair features. No external business lookup or ID-number features."""
from __future__ import annotations
import math
from functools import lru_cache
from rapidfuzz import fuzz
from normalization import skeleton
KINDS=('e','n','p','s','a','h','b','d','v')
FEATURE_NAMES=(
    'core_ratio','core_token_set','core_partial','core_token_sort',
    'raw_name_ratio','raw_name_token_set','raw_name_wratio',
    'skeleton_name_ratio','name_word_exact','name_word_containment','name_word_jaccard',
    'name_word_best_q','name_word_best_t','name_word_max_fuzzy',
    'address_ratio','address_token_set','address_token_sort','address_partial',
    'address_word_exact','address_word_containment','address_word_jaccard',
    'address_word_best_q','address_word_best_t','address_word_max_fuzzy',
    'num_shared','num_containment','num_first_equal','num_conflict_single',
    'num_count_query','num_count_target','num_max_shared_len',
    'region_exact','region_fuzzy','missing_target_address','target_domain_name',
    'name_len_ratio','addr_len_ratio','core_word_count_query','core_word_count_target',
    'target_source3','support_log','pre_rank',
    'name_jaro','name_jaccard','address_jaccard','address_token_containment','number_overlap',
)+tuple('hits_'+k for k in KINDS)
def words(text:str|None)->tuple[str,...]:return tuple((text or '').split())
@lru_cache(maxsize=250000)
def skeleton_phrase(s:str)->str:return ' '.join(skeleton(t) for t in s.split())
@lru_cache(maxsize=250000)
def _word_set(text:str)->frozenset[str]:return frozenset(text.split())
def overlaps(x:str|None,y:str|None)->tuple[int,float,float]:
    a=_word_set(x or '');b=_word_set(y or '')
    if not a or not b:return 0,0.,0.
    n=len(a&b);return n,n/min(len(a),len(b)),n/len(a|b)
@lru_cache(maxsize=250000)
def _top_terms(text:str,limit:int)->tuple[str,...]:return tuple(sorted(_word_set(text),key=lambda t:(-len(t),t))[:limit])
def best_word_similarity(x:str|None,y:str|None,limit:int=5)->tuple[float,float,float]:
    a=_top_terms(x or '',limit);b=_top_terms(y or '',limit)
    if not a or not b:return 0.,0.,0.
    def best(src,dst):
        dset=set(dst)
        return [1. if t in dset else max(fuzz.ratio(t,u) for u in dst)/100 for t in src]
    v=best(a,b);w=best(b,a);return sum(v)/len(v),sum(w)/len(w),max(v)
def feature_row(r:dict)->list[float]:
    qc=(r['qcore'] or '');tc=(r['tcore'] or '');qn=(r['qname'] or '');tn=(r['tname'] or '')
    qa=(r['qaddr'] or '');ta=(r['taddr'] or '');qnt=(r['qnterms'] or '');tnt=(r['tnterms'] or '')
    qat=(r['qaterms'] or '');tat=(r['taterms'] or '');qnum=(r['qnums'] or '');tnum=(r['tnums'] or '')
    qr=(r['qregion'] or '');tr=(r['tregion'] or '')
    ne,nc,nj=overlaps(qnt,tnt);ae,ac,aj=overlaps(qat,tat)
    nbest=best_word_similarity(qnt,tnt,5);abest=best_word_similarity(qat,tat,5)
    nums1=words(qnum);nums2=words(tnum);common=set(nums1)&set(nums2)
    reg1=words(qr);reg2=words(tr)
    x=[
        fuzz.ratio(qc,tc)/100 if qc and tc else 0.,
        fuzz.token_set_ratio(qc,tc)/100 if qc and tc else 0.,
        fuzz.partial_ratio(qc,tc)/100 if qc and tc else 0.,
        fuzz.token_sort_ratio(qc,tc)/100 if qc and tc else 0.,
        fuzz.ratio(qn,tn)/100,fuzz.token_set_ratio(qn,tn)/100,fuzz.WRatio(qn,tn)/100,
        fuzz.ratio(skeleton_phrase(qc),skeleton_phrase(tc))/100 if qc and tc else 0.,
        ne,nc,nj,*nbest,
        fuzz.ratio(qa,ta)/100 if qa and ta else 0.,
        fuzz.token_set_ratio(qa,ta)/100 if qa and ta else 0.,
        fuzz.token_sort_ratio(qa,ta)/100 if qa and ta else 0.,
        fuzz.partial_ratio(qa,ta)/100 if qa and ta else 0.,
        ae,ac,aj,*abest,
        len(common),len(common)/min(len(nums1),len(nums2)) if nums1 and nums2 else 0.,
        int(bool(nums1 and nums2 and nums1[0]==nums2[0])),
        int(len(nums1)==len(nums2)==1 and nums1[0]!=nums2[0]),
        min(len(nums1),10),min(len(nums2),10),max(map(len,common),default=0),
        int(bool(set(reg1)&set(reg2))),
        max((fuzz.ratio(a,b)/100 for a in reg1 for b in reg2),default=0.),
        int(not bool(ta)),int('com' in tn.split() or 'www' in tn.split()),
        min(len(qc),len(tc))/max(1,len(qc),len(tc)),
        min(len(qa),len(ta))/max(1,len(qa),len(ta)),
        min(len(qnt.split()),10),min(len(tnt.split()),10),
        int(r['tid'].startswith('S3-')),
        math.log1p(max(0.,float(r['support']))),int(r['rnk']),
        *[float(r[f]) if r[f] is not None else 0. for f in
          ('name_jaro','name_jaccard','address_jaccard','address_token_containment','number_overlap')],
        *[int(r['hits_'+k] or 0) for k in KINDS],
    ]
    assert len(x)==len(FEATURE_NAMES),(len(x),len(FEATURE_NAMES))
    return x
