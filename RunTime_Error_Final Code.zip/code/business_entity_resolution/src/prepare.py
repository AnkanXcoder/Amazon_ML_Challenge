"""Stream authentic provided TSVs to memory-bounded Parquet records and base keys."""
from __future__ import annotations
import argparse,csv,json,logging
from pathlib import Path
import duckdb,xxhash
from normalization import from_tsv,blocking_keys
LOG=logging.getLogger(__name__);BUCKETS=16;HASH_MASK=(1<<63)-1
def hashed(country:str,key:str)->int:
    return xxhash.xxh3_64_intdigest(country+'|'+key)&HASH_MASK
def validate_input(path:Path,expected:str):
    if not path.is_file():raise FileNotFoundError(f'Missing input {path}; git lfs pull is needed')
    with path.open('rb') as f:head=f.read(140)
    if head.startswith(b'version https://git-lfs.github.com/spec/v1'):
        raise ValueError(f'Git LFS POINTER, not real TSV: {path}')
    if not head.startswith(expected.encode()):raise ValueError(f'Incorrect TSV header {path}: {head!r}')
def set_duckdb(db_path:Path,work:Path):
    tmp=work/'duckdb_tmp';tmp.mkdir(parents=True,exist_ok=True)
    con=duckdb.connect(str(db_path));con.execute("SET memory_limit='950MB'")
    con.execute('SET threads=2');con.execute('SET temp_directory=?',[str(tmp)])
    return con
def sq(path:Path)->str:return "'"+str(path).replace("'","''")+"'"
def convert_stage(work:Path,name:str):
    con=set_duckdb(work/'prepare.duckdb',work);raw=work/f'{name}.tsv';pq=work/f'{name}.parquet'
    if name.endswith('_records'):
        types={'idx':'INTEGER','entity_id':'VARCHAR','country':'VARCHAR','name':'VARCHAR','core':'VARCHAR','addr':'VARCHAR','nterms':'VARCHAR','aterms':'VARCHAR','nums':'VARCHAR','region':'VARCHAR'}
    else:types={'key':'BIGINT','idx':'INTEGER','kind':'VARCHAR'}
    cols='{'+','.join(f"'{k}':'{v}'" for k,v in types.items())+'}'
    LOG.info('Converting %s (%.1f MB)',raw.name,raw.stat().st_size/1e6)
    con.execute(f"COPY (SELECT * FROM read_csv({sq(raw)}, delim='\\t', header=true, columns={cols}, null_padding=false)) TO {sq(pq)} (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 100000)")
    con.close();raw.unlink()
def write_records(split:str,data_dir:Path,work:Path,role:str,train_size:int,val_size:int,max_per_file:int|None):
    work.mkdir(parents=True,exist_ok=True);keys_dir=work/f'{role}_keys';keys_dir.mkdir(exist_ok=True)
    handles=[(keys_dir/f'key_{b:02d}.tsv').open('w',encoding='ascii',buffering=4*1024*1024) for b in range(BUCKETS)]
    for h in handles:h.write('key\tidx\tkind\n')
    n=k=0;countries={}
    with (work/f'{role}_records.tsv').open('w',encoding='utf-8',newline='',buffering=4*1024*1024) as out:
        writer=csv.writer(out,delimiter='\t',lineterminator='\n')
        writer.writerow(('idx','entity_id','country','name','core','addr','nterms','aterms','nums','region'))
        for source in ([2,3] if role=='targets' else [1]):
            path=data_dir/split/f'{split}_source{source}.tsv'
            validate_input(path,'entity_id\tbusiness_name\tbusiness_address\tcountry')
            LOG.info('Normalizing %s',path);processed=0
            with path.open(encoding='utf-8',newline='',buffering=4*1024*1024) as inp:
                for row in csv.DictReader(inp,delimiter='\t'):
                    if max_per_file and processed>=max_per_file:break
                    processed+=1
                    if role=='queries' and split=='train':
                        hv=xxhash.xxh3_64_intdigest(row['entity_id'])%1000
                        if hv>=train_size+val_size:continue
                    r=from_tsv(row);countries[r.country]=countries.get(r.country,0)+1
                    writer.writerow((n,r.entity_id,r.country,r.name,r.name_core,r.address,' '.join(r.name_terms),' '.join(r.addr_terms),' '.join(r.numbers),' '.join(r.region_terms)))
                    for key in blocking_keys(r):
                        kh=hashed(r.country,key);handles[kh%BUCKETS].write(f'{kh}\t{n}\t{key[0]}\n');k+=1
                    n+=1
                    if n%1_000_000==0:LOG.info('%s: %.1fM records %.1fM keys',role,n/1e6,k/1e6)
    for h in handles:h.close()
    LOG.info('%s: records=%d keys=%d countries=%s',role,n,k,countries)
    convert_stage(work,f'{role}_records')
    for b in range(BUCKETS):convert_stage(keys_dir,f'key_{b:02d}')
    return {'records':n,'keys':k,'countries':countries}
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data-dir',required=True,type=Path);p.add_argument('--work-dir',required=True,type=Path)
    p.add_argument('--split',required=True,choices=['train','test']);p.add_argument('--role',choices=['targets','queries','both'],default='both')
    p.add_argument('--train-size',type=int,default=25);p.add_argument('--val-size',type=int,default=20)
    p.add_argument('--max-per-file',type=int)
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    work=a.work_dir/a.split;work.mkdir(parents=True,exist_ok=True);mf=work/'prepare_manifest.json'
    manifest=json.loads(mf.read_text()) if mf.exists() else {}
    for role in (['targets','queries'] if a.role=='both' else [a.role]):
        keydir=work/f'{role}_keys';record=work/f'{role}_records.parquet'
        complete=record.is_file() and all((keydir/f'key_{i:02d}.parquet').is_file() for i in range(BUCKETS))
        if complete:
            complete=manifest.get('max_per_file')==a.max_per_file and role in manifest
            if role=='queries' and a.split=='train':complete=complete and manifest.get('train_size')==a.train_size and manifest.get('val_size')==a.val_size
        if complete:LOG.info('Reuse %s',role);continue
        if record.exists():record.unlink()
        if keydir.exists():
            for f in keydir.glob('*.parquet'):f.unlink()
        manifest[role]=write_records(a.split,a.data_dir,work,role,a.train_size,a.val_size,a.max_per_file)
    manifest.update(split=a.split,train_size=a.train_size,val_size=a.val_size,max_per_file=a.max_per_file)
    mf.write_text(json.dumps(manifest,indent=2));print(json.dumps(manifest,indent=2))
if __name__=='__main__':main()
