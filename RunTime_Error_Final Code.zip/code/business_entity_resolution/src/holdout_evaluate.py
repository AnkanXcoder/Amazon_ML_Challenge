"""Once-only locked holdout check (hash buckets 33..44): no threshold tuning."""
from __future__ import annotations
import argparse,json,logging,time,collections
from pathlib import Path
import numpy as np,pyarrow.parquet as pq,lightgbm as lgb
from train_model import query_info
from metrics import macro_f05
from features import feature_row,FEATURE_NAMES
LOG=logging.getLogger(__name__)
def evaluate(work:Path,truth_file:Path,model_file:Path,config:Path,report:Path):
    fold,country,truth,tcount=query_info(work,truth_file)
    hold=np.flatnonzero((fold>=33)&(fold<45));meta=json.loads(config.read_text());k=int(meta['topk']);threshold=float(meta['threshold'])
    nmax=len(hold)*k;X=np.empty((nmax,len(FEATURE_NAMES)),dtype=np.float32);y=np.empty(nmax,dtype=np.int8)
    qidx=np.empty(nmax,dtype=np.int32);rank=np.empty(nmax,dtype=np.int8);tids=[];pos=0;start=time.time()
    for b in pq.ParquetFile(work/'training_joined.parquet').iter_batches(batch_size=15000):
        z=b.to_pydict();fields=list(z)
        for vals in zip(*(z[f] for f in fields)):
            r=dict(zip(fields,vals));q=r['qidx']
            if not 33<=fold[q]<45 or r['rnk']>k:continue
            X[pos]=feature_row(r);y[pos]=int(r['tid'] in truth[q]);qidx[pos]=q;rank[pos]=r['rnk'];tids.append(r['tid']);pos+=1
    LOG.info('Locked holdout %d S1 %d candidate pairs %.1fs',len(hold),pos,time.time()-start)
    model=lgb.Booster(model_file=str(model_file));pr=model.predict(X[:pos],num_threads=2)
    out=macro_f05(qidx[:pos],y[:pos],pr,rank[:pos],tcount,hold,threshold,topk=k,country=country)
    out.update({'hash_range':[33,45],'topk':k,'threshold':threshold,'candidate_pairs_scored':pos,
                'candidate_link_recall':int(y[:pos].sum())/int(tcount[hold].sum()),
                'note':'This locked holdout did not influence training or development threshold.'})
    report.parent.mkdir(parents=True,exist_ok=True);report.write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));return out
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True,type=Path)
    p.add_argument('--truth',required=True,type=Path);p.add_argument('--model',required=True,type=Path)
    p.add_argument('--config',required=True,type=Path);p.add_argument('--report',required=True,type=Path)
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    evaluate(a.work,a.truth,a.model,a.config,a.report)
