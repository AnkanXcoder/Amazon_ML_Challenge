# RunTime Error — Submission Instructions for the Portal Shown in the Image

**Team:** RunTime Error. **Members:** ANKAN SEN (Team Leader), Subhadip Bera, Nilanjan Nayak, and Sudam Mahato. The personal phone numbers visible in the image were not included in any submission document or ZIP archive. On your screen, you will see **two separate upload fields**: `Upload Matching Results File` (TSV) and `Upload Code File` (ZIP).

| Upload Field | File |
|:--|:--|
| **Upload Matching Results File** | The extracted `output/matching_results.tsv` from `RunTime_Error_submission.zip` — this is the actual TSV file, not a ZIP archive. |
| **Upload Code File** | **`RunTime_Error_code.zip`** — approximately 1 MB, a standard Deflate ZIP containing runnable code, a trained model, pinned requirements, methodology, and reports. |

**`RunTime_Error_submission.zip`** is a separate, complete self-contained **final package**: in addition to all of the above, it contains two large TSV files (`output/matching_results.tsv` and `output/candidate_pairs.tsv`). If a future final-package submission or the organizer requires the complete package in the same field, use this ZIP. However, in the portal shown in the image, you should first upload the smaller standard `RunTime_Error_code.zip` in the **Code File** field. There is no clear indication in the image of any separate ZIP-size limit. The code ZIP does not contain `candidate_pairs.tsv`, so if the full final package is required, the smaller code ZIP is not a substitute.

## How to Extract the First TSV File — Important

The full `RunTime_Error_submission.zip` was created using **ZIP-LZMA** to reduce storage space. Standard Windows **Extract All**, PowerShell **Expand-Archive**, and many Linux `unzip` implementations do not support LZMA. This does not mean the ZIP is corrupted; please use one of the following methods:

1. **Simple graphical method:** Open `RunTime_Error_submission.zip` in 7-Zip or another ZIP-LZMA-compatible extractor → open the `output` folder → select `matching_results.tsv` → **Extract**. You will get a file of approximately 92 MB. No matter where you extract it, select this actual **`.tsv` file** in the first upload field.
2. **If Python 3 is available, use Windows Command Prompt or PowerShell:** Run the following command in the folder where the ZIP is located:

   ```powershell
   py -3 -m zipfile -e .\RunTime_Error_submission.zip .\RunTime_Error
   # First upload field: .\RunTime_Error\output\matching_results.tsv
   ```

   On Linux/macOS, use:

   ```sh
   python3 -m zipfile -e RunTime_Error_submission.zip RunTime_Error
   # First upload field: RunTime_Error/output/matching_results.tsv
   ```

   Python’s built-in `zipfile` **supports ZIP-LZMA**. If you extract the entire archive, keep about 350 MB of free space available. You can also extract only the required file `output/matching_results.tsv` using Python’s `zipfile` without extracting the whole archive. **Do not rename the `.zip` file to `.tsv`.**

## Submission Steps

1. Download both `RunTime_Error_submission.zip` and `RunTime_Error_code.zip`. Extract `matching_results.tsv` from the full ZIP using the method described above.
2. In the portal, select `matching_results.tsv` in the **first upload field** and `RunTime_Error_code.zip` in the **second upload field**. In other words, upload the TSV first and the ZIP second. In the file chooser, verify that the actual extensions are `.tsv` and `.zip`.
3. Wait until both uploads are complete, then click **Submit & Evaluate**. If the portal shows a success message, an error, or a score, keep a screenshot or receipt of the result. I am not able to log in to the portal or submit on your behalf; this must be done by you.

## Pre-Submission Verification

- The first TSV contains the header `source1_entity_id<TAB>matched_entity_ids`. It includes a total of **1,732,544** S1 rows (+1 header), including **259,452** France S1 rows. The file size is **92,374,094 bytes**.
- The portal’s first TSV must match the full ZIP’s `output/matching_results.tsv` exactly. The SHA-256 is: `15fde0441dc1e952927417151f0caffab75bc3ea8879ac1bacd48f429c1480bc`. If needed, on Windows you can verify it with:

  ```powershell
  Get-FileHash .\RunTime_Error\output\matching_results.tsv -Algorithm SHA256
  ```

- The organizer’s matching-results validator **PASS**. In addition, the full two-TSV validation — including header correctness, actual IDs for each S1, S2/S3, duplicates, and the condition `matches ⊆ candidates` — also **PASS**; the full ZIP contains the validation report. The organizer’s very memory-intensive two-file validator was not run on this machine.
- The team name and the names of the four members, along with the methodology and README, match the image exactly; please check the spelling one final time before submission. The Test/French F₀.₅ or leaderboard score is not known before the official submission.

**If any error occurs**, please share the portal’s error text or a screenshot so I can help identify whether the issue is related to the upload, archive support, or size limits. No actual maximum upload size is visible in the image, so I am not claiming that the upload will succeed until the portal accepts it successfully.
