"""Small deterministic integrity checks (no test labels, network or external data)."""
from __future__ import annotations
from pathlib import Path
import numpy as np,lightgbm as lgb
from normalization import normalize,blocking_keys
from metrics import macro_f05
from features import FEATURE_NAMES,feature_row

def main():
    q=normalize('S1-1','France','École Lumière SARL','12 Rue de la Liberté, Lyon')
    assert q.country=='france' and 'ecole' in q.name and len(blocking_keys(q))>1
    assert normalize('S1-2','India','ABC Ltd','').address==''
    # Correct singleton=1, incorrectly linked singleton=0; include all S1 groups.
    s=macro_f05(np.array([0,1,2]),np.array([1,0,0]),np.array([.9,.1,.9]),
                np.array([1,1,1]),np.array([1,0,0]),np.array([0,1,2]),.66,topk=10)
    assert abs(s['macro_f05']-2/3)<1e-10 and s['singleton_count']==2
    r={k:'' for k in ('qcore','tcore','qname','tname','qaddr','taddr','qnterms','tnterms','qaterms','taterms','qnums','tnums','qregion','tregion')}
    r.update({k:0 for k in ('support','rnk','name_jaro','name_jaccard','address_jaccard','address_token_containment','number_overlap')})
    r.update({'tid':'S2-1',**{'hits_'+k:0 for k in 'enpsahbdv'}})
    assert len(FEATURE_NAMES)==len(feature_row(r))==56
    model=lgb.Booster(model_file=str(Path(__file__).resolve().parents[1]/'model.txt'))
    assert model.feature_name()==list(FEATURE_NAMES) and model.num_trees()==430
    print('PASS · open-country normalization, singleton metric, 56 features, 430-tree model order')
if __name__=='__main__':main()
