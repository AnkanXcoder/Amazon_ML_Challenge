"""MIT LightGBM: fit hard blocking negatives; tune exact entity-macro F0.5 on dev."""
from __future__ import annotations
import argparse,csv,json,logging,time
from pathlib import Path
import numpy as np,pyarrow.parquet as pq,xxhash,lightgbm as lgb
from features import feature_row,FEATURE_NAMES
from join_pairs import attach
from metrics import search_threshold
LOG=logging.getLogger(__name__);FOLD_TRAIN_END=25;FOLD_DEV_END=33;SEED=2026
def query_info(work:Path,ground_truth:Path):
    qm={};fold=[];country=[]
    for b in pq.ParquetFile(work/'queries_records.parquet').iter_batches(columns=['idx','entity_id','country'],batch_size=100000):
        z=b.to_pydict()
        for idx,q,c in zip(z['idx'],z['entity_id'],z['country']):
            assert idx==len(fold);qm[q]=idx;fold.append(xxhash.xxh3_64_intdigest(q)%1000);country.append(c)
    truth={};tcount=np.zeros(len(fold),dtype=np.int16)
    with ground_truth.open(encoding='utf-8',newline='') as fh:
        for r in csv.DictReader(fh,delimiter='\t'):
            idx=qm.get(r['source1_entity_id'])
            if idx is None:continue
            matches=frozenset(r['matched_entity_ids'].split(',')) if r['matched_entity_ids'] else frozenset()
            truth[idx]=matches;tcount[idx]=len(matches)
    assert len(truth)==len(fold),(len(truth),len(fold))
    return np.array(fold,dtype=np.int16),np.array(country,dtype='U32'),truth,tcount
def extract(work:Path,ground_truth:Path):
    joined=work/'training_joined.parquet'
    if not joined.exists():attach(work,0,2**31-1,joined)
    n=pq.ParquetFile(joined).metadata.num_rows
    folds,country,truth,tcount=query_info(work,ground_truth)
    train_q=np.flatnonzero(folds<FOLD_TRAIN_END);dev_q=np.flatnonzero((folds>=FOLD_TRAIN_END)&(folds<FOLD_DEV_END))
    LOG.info('Train %d S1; dev %d S1; joined %d pairs',len(train_q),len(dev_q),n)
    matdir=work/'model_matrix';matdir.mkdir(exist_ok=True);f=len(FEATURE_NAMES)
    X=np.memmap(matdir/'train_f32.mmap',dtype=np.float32,mode='w+',shape=(n,f))
    V=np.memmap(matdir/'dev_f32.mmap',dtype=np.float32,mode='w+',shape=(n,f))
    y=np.empty(n,dtype=np.int8);vy=np.empty(n,dtype=np.int8);dq=np.empty(n,dtype=np.int32);dr=np.empty(n,dtype=np.uint8)
    used=du=pos=0;begin=time.time()
    for b in pq.ParquetFile(joined).iter_batches(batch_size=15000):
        z=b.to_pydict();keys=list(z)
        for vals in zip(*(z[k] for k in keys)):
            row=dict(zip(keys,vals));qid=int(row['qidx']);fold=folds[qid]
            if fold>=FOLD_DEV_END:continue
            label=int(row['tid'] in truth[qid])
            if fold<FOLD_TRAIN_END:
                if not label and int(row['rnk'])>16 and xxhash.xxh3_64_intdigest(row['qid']+'|'+row['tid'])%6!=0:continue
                X[used]=feature_row(row);y[used]=label;used+=1;pos+=label
            else:
                V[du]=feature_row(row);vy[du]=label;dq[du]=qid;dr[du]=int(row['rnk']);du+=1
        if (used+du)%200000<15000:LOG.info('Features %.1fM train + %.1fM dev %.1fs',used/1e6,du/1e6,time.time()-begin)
    X.flush();V.flush();LOG.info('Feature extraction %.1fs: train %d (%d positive), dev %d (%d positive)',time.time()-begin,used,pos,du,int(vy[:du].sum()))
    return X[:used],y[:used],V[:du],vy[:du],dq[:du],dr[:du],tcount,folds,country,train_q,dev_q
def train(work:Path,ground_truth:Path,artifact:Path,report:Path):
    X,y,V,vy,vqid,vrank,tcount,folds,country,train_q,dev_q=extract(work,ground_truth)
    assert np.isfinite(X).all() and np.isfinite(V).all()
    params={'objective':'binary','metric':'auc','learning_rate':.065,'num_leaves':47,'max_bin':127,'min_data_in_leaf':95,
            'feature_fraction':.88,'bagging_fraction':.82,'bagging_freq':1,'lambda_l2':4.,
            'num_threads':2,'verbosity':-1,'seed':SEED,'deterministic':True,'force_col_wise':True}
    dtrain=lgb.Dataset(X,label=y,feature_name=list(FEATURE_NAMES),params={'max_bin':127})
    dval=lgb.Dataset(V,label=vy,reference=dtrain);begin=time.time()
    model=lgb.train(params,dtrain,num_boost_round=430,valid_sets=[dval],valid_names=['dev'],callbacks=[lgb.early_stopping(40,verbose=True),lgb.log_evaluation(60)])
    LOG.info('MIT model trained %d trees in %.1fs',model.best_iteration,time.time()-begin)
    prob=model.predict(V,num_iteration=model.best_iteration,num_threads=2)
    results={}
    for k in (8,10,11,12,16,20,24,32,40):
        threshold,metrics,curve=search_threshold(vqid,vy,prob,vrank,tcount,dev_q,topk=k,country=country)
        results[str(k)]={'threshold':threshold,**metrics,'threshold_curve':curve}
        LOG.info('Dev top-%d macro-F05 %.6f threshold %.4f P %.4f R %.4f',k,metrics['macro_f05'],threshold,metrics['micro_precision'],metrics['micro_recall'])
    best_k=10;threshold=results[str(best_k)]['threshold']
    summary={'model':'LightGBM 4.6.0 MIT; 47 leaves binary GBDT','training_entities':len(train_q),'development_entities':len(dev_q),
             'training_pairs':len(y),'training_positive_pairs':int(y.sum()),'development_pairs':len(vy),
             'development_positive_pairs_in_candidates':int(vy.sum()),'development_true_links':int(tcount[dev_q].sum()),
             'trees':int(model.best_iteration),'features':list(FEATURE_NAMES),'train_hash_range':[0,25],
             'development_hash_range':[25,33],'topk_default':best_k,'threshold_default':threshold,
             'results_by_topk':results,'top_feature_importances_gain':sorted(zip(FEATURE_NAMES,model.feature_importance(importance_type='gain').tolist()),key=lambda x:-x[1])[:25]}
    artifact.parent.mkdir(parents=True,exist_ok=True);report.parent.mkdir(parents=True,exist_ok=True)
    model.save_model(str(artifact),num_iteration=model.best_iteration)
    artifact.with_suffix('.json').write_text(json.dumps({'threshold':threshold,'topk':best_k,'feature_names':list(FEATURE_NAMES),'model_file':artifact.name},indent=2))
    report.write_text(json.dumps(summary,indent=2));LOG.info('Wrote model %s, report %s',artifact,report);return summary
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',required=True,type=Path)
    p.add_argument('--ground-truth',required=True,type=Path);p.add_argument('--model',required=True,type=Path)
    p.add_argument('--report',required=True,type=Path);a=p.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    train(a.work,a.ground_truth,a.model,a.report)
