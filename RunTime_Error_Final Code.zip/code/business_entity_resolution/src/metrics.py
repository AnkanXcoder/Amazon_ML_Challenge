"""Exact macro per-S1 F0.5, including empty/no-match entities."""
import numpy as np
def macro_f05(qidx:np.ndarray,truth:np.ndarray,probability:np.ndarray,rank:np.ndarray,truth_count:np.ndarray,evaluated_indices:np.ndarray,threshold:float,topk:int|None=None,country:np.ndarray|None=None)->dict:
    n=len(truth_count);selected=(probability>=threshold)
    if topk is not None:selected &= rank<=topk
    g=truth_count.astype(np.int32,copy=False)
    tp=np.bincount(qidx,weights=(selected & (truth==1)).astype(np.int8),minlength=n)[evaluated_indices]
    pred=np.bincount(qidx,weights=selected.astype(np.int8),minlength=n)[evaluated_indices]
    gt=g[evaluated_indices];den=1.25*tp+0.25*(gt-tp)+(pred-tp)
    score=np.where(den>0,1.25*tp/np.maximum(den,1e-12),(gt==0).astype(float))
    single=(gt==0)
    out={'macro_f05':float(score.mean()),'micro_precision':float(tp.sum()/max(1.,pred.sum())),
         'micro_recall':float(tp.sum()/max(1.,gt.sum())),'singleton_count':int(single.sum()),
         'singleton_correct_rate':float((pred[single]==0).mean()) if single.any() else float('nan'),
         'predicted_links':int(pred.sum()),'true_links':int(gt.sum()),'correct_links':int(tp.sum()),'entities':len(evaluated_indices)}
    if country is not None:out['macro_by_country']={str(c):float(score[country[evaluated_indices]==c].mean()) for c in np.unique(country[evaluated_indices])}
    return out
def search_threshold(qidx,truth,probability,rank,truth_count,eval_indices,topk=None,country=None):
    grid=np.unique(np.concatenate([np.arange(.02,.98,.02),np.arange(.80,.991,.005),np.arange(.990,.9991,.001),np.array([.9995,.9999])]))
    curve=[];best=None
    for t in grid:
        m=macro_f05(qidx,truth,probability,rank,truth_count,eval_indices,float(t),topk,country)
        curve.append((round(float(t),6),round(m['macro_f05'],6)))
        if best is None or m['macro_f05']>best[1]['macro_f05']:best=(float(t),m)
    return best[0],best[1],curve
