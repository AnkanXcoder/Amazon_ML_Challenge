"""Unsupervised 1%-of-provided-target rarity sketch adds informative address keys."""
from __future__ import annotations
import argparse,json,itertools,logging,collections
from pathlib import Path
import pyarrow.parquet as pq
from normalization import ADDR_GENERIC
from prepare import hashed,BUCKETS,convert_stage,set_duckdb,sq
from augment_keys import composite_keys
LOG=logging.getLogger(__name__)
def target_frequency(work:Path)->collections.Counter:
    con=set_duckdb(work/'idf.duckdb',work)
    table=con.execute(f'SELECT addr FROM read_parquet({sq(work/"targets_records.parquet")}) WHERE idx % 100 = 0').fetch_arrow_table()
    con.close();freq=collections.Counter()
    for addr in table.column('addr').to_pylist():
        freq.update(set(t for t in (addr or '').split() if len(t)>=3 and t.isalpha() and t not in ADDR_GENERIC))
    LOG.info('%d rare-address vocabulary terms from %d target sample',len(freq),len(table));return freq
def idf_composite(nterms:str|None,addr:str|None,nums:str|None,freq:collections.Counter):
    words=tuple(dict.fromkeys((addr or '').split()))
    words=sorted((t for t in words if len(t)>=3 and t.isalpha() and t not in ADDR_GENERIC),key=lambda t:(freq.get(t,0),-len(t),t))[:5]
    numbers=tuple(dict.fromkeys((nums or '').split()))[:4]
    for a,b in itertools.combinations(words,2):yield 'd:'+min(a,b)+':'+max(a,b)
    for n in numbers:
        if len(n)>=2:
            for a in words:yield 'v:'+n+':'+a
def augment(work:Path,role:str,freq:collections.Counter)->int:
    dest=work/f'{role}_keys';n=0
    handles=[(dest/f'key_{i:02d}_idf.tsv').open('w',encoding='ascii',buffering=4*1024*1024) for i in range(BUCKETS)]
    for f in handles:f.write('key\tidx\tkind\n')
    for b in pq.ParquetFile(work/f'{role}_records.parquet').iter_batches(columns=['idx','country','nterms','addr','nums'],batch_size=50000):
        z=b.to_pydict()
        for idx,c,name,addr,nums in zip(z['idx'],z['country'],z['nterms'],z['addr'],z['nums']):
            base=set(composite_keys(name,addr,nums))
            for key in sorted(set(idf_composite(name,addr,nums,freq))-base):
                h=hashed(c,key);handles[h%BUCKETS].write(f'{h}\t{idx}\t{key[0]}\n');n+=1
        if b.num_rows and (z['idx'][-1]+1)%1_000_000<b.num_rows:
            LOG.info('%s IDF %.1fM rows %.1fM keys',role,(z['idx'][-1]+1)/1e6,n/1e6)
    for f in handles:f.close()
    for i in range(BUCKETS):convert_stage(dest,f'key_{i:02d}_idf')
    LOG.info('%s extra IDF keys %d',role,n);return n
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work-dir',required=True,type=Path)
    p.add_argument('--split',required=True,choices=['train','test']);p.add_argument('--role',choices=['targets','queries','both'],default='both')
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    w=a.work_dir/a.split
    if not all((w/f'targets_keys/key_{b:02d}_extra.parquet').is_file() for b in range(BUCKETS)):
        p.error('Run augment_keys.py for both sources first')
    freq=target_frequency(w);result={}
    for role in (['targets','queries'] if a.role=='both' else [a.role]):
        d=w/f'{role}_keys'
        if all((d/f'key_{b:02d}_idf.parquet').is_file() for b in range(BUCKETS)):
            LOG.info('Reuse complete IDF index %s',role);continue
        for f in d.glob('key_*_idf.parquet'):f.unlink()
        result[role]=augment(w,role,freq)
    (w/'idf_manifest.json').write_text(json.dumps(result,indent=2));print(result)
if __name__=='__main__':main()
