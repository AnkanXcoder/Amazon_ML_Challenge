"""Challenge-only, open-country business-string normalization and base blocking keys."""
from __future__ import annotations
import re,unicodedata
from dataclasses import dataclass
from unidecode import unidecode
_WORD=re.compile(r'[a-z0-9]+');_NUMBER=re.compile(r'\d+')
LEGAL=frozenset(('the and of for in on at a an inc incorporated corp corporation llc llp ltd limited pvt private co company plc sa sarl gmbh pte enterprises enterprise').split())
ADDR_GENERIC=frozenset(('the of and near opposite opp road rd street st avenue ave lane ln drive dr boulevard blvd place pl circle cir building bldg block floor fl unit suite apartment apt house no number hno h flat f north south east west city district state post office po box village vlg highway hwy behind').split())
ABBREV={'corporation':'corp','incorporated':'inc','limited':'ltd','private':'pvt','company':'co','road':'rd','street':'st','avenue':'ave','drive':'dr','boulevard':'blvd','lane':'ln','apartment':'apt','suite':'ste','highway':'hwy','floor':'fl','number':'no'}
_SK_MAP={ord(c):None for c in 'aeiou'}
_SK_MAP.update({ord(a):ord(b) for a,b in (('w','v'),('c','k'),('q','k'),('z','s'))})
_SK_DUP=re.compile(r'(.)\1+')
def skeleton(term:str)->str:
    term=term.replace('ph','f').replace('qu','k').replace('ck','k').translate(_SK_MAP)
    return _SK_DUP.sub(r'\1',term)
LEGAL_PHONETIC=frozenset(skeleton(t) for t in LEGAL if len(t)>=5 and len(skeleton(t))>=4)
def is_legal(t:str)->bool:
    return t in LEGAL or (len(t)>=6 and skeleton(t) in LEGAL_PHONETIC)
def transliterate(text:str)->str:
    if not text.isascii():text=unidecode(unicodedata.normalize('NFKC',text))
    return text.lower().replace('&',' and ')
def tokenize(text:str)->tuple[str,...]:
    return tuple(ABBREV.get(x,x) for x in _WORD.findall(transliterate(text)))
def nums_from_address(words:tuple[str,...])->tuple[str,...]:
    out=[]
    for w in words:
        for n in _NUMBER.findall(w):
            if len(n)<=7:
                n=n.lstrip('0') or '0'
                if n not in out:out.append(n)
    return tuple(out)
@dataclass(frozen=True,slots=True)
class Record:
    entity_id:str
    country:str
    name:str
    address:str
    name_core:str
    name_terms:tuple[str,...]
    addr_terms:tuple[str,...]
    numbers:tuple[str,...]
    region_terms:tuple[str,...]
def normalize(entity_id:str,country:str,name:str,address:str)->Record:
    n=tokenize(name);a=tokenize(address)
    core=tuple(t for t in n if not is_legal(t))
    nt=tuple(dict.fromkeys(t for t in core if len(t)>=3))
    at=tuple(dict.fromkeys(t for t in a if len(t)>=4 and t not in ADDR_GENERIC and not t.isdigit()))
    region=tuple(dict.fromkeys(t for t in reversed(a) if t not in ADDR_GENERIC and t.isalpha()))[:2]
    return Record(entity_id,country.strip().casefold(),' '.join(n),' '.join(a),' '.join(sorted(core)),nt,at,nums_from_address(a),region)
def blocking_keys(rec:Record)->tuple[str,...]:
    keys=[]
    if rec.name_core:keys.append('e:'+rec.name_core)
    name=sorted(rec.name_terms,key=lambda x:(-len(x),x))
    for t in name[:4]:keys.append('n:'+t)
    for t in name[:2]:
        if len(t)>=5:keys.append('p:'+t[:4])
        sk=skeleton(t)
        if len(t)>=5 and len(sk)>=3:keys.append('s:'+sk[:7])
    for t in sorted(rec.addr_terms,key=lambda x:(-len(x),x))[:5]:keys.append('a:'+t)
    for number in rec.numbers[:3]:
        if len(number)>=2:
            for region in rec.region_terms:keys.append('h:'+number+':'+region)
    return tuple(dict.fromkeys(keys))
def from_tsv(row:dict[str,str])->Record:
    return normalize(row['entity_id'],row['country'],row['business_name'],row['business_address'])
