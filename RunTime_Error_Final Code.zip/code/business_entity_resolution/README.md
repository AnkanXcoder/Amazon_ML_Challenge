# Business Entity Resolution · Amazon ML Challenge 2026

**Team:** RunTime Error · **Members:** ANKAN SEN (Team Leader); Subhadip Bera; Nilanjan NAYAK; Sudam Mahato. Team identity was supplied in the participant's portal screenshot; personal contact details are intentionally not included.

## Deliverable & data boundary

The final archive contains `output/matching_results.tsv` and `output/candidate_pairs.tsv`; both are headered, tab-separated UTF-8 files with **one row per test S1**, including France and empty result lists. A comma-separated ID list is the second column. Every predicted match is an S2/S3 ID in that query's **final post-rerank, pre-classifier scored** candidate list. Capping candidates is required to keep the self-contained submission within the workspace's size limit; the frozen cap is **10** candidates per S1, chosen on labeled development performance and an output-compression budget, *not* from the untouched holdout. The complete `RunTime_Error_submission.zip` also includes this code, fitted `model.txt`, `model.json`, reports, completed methodology template and `RunTime_Error_আপলোড_নির্দেশনা.md`. That full package uses ZIP-LZMA to fit the workspace limit; extract its `output/matching_results.tsv` using Python's `zipfile` or 7-Zip (many default `unzip`/Windows extractors cannot handle ZIP-LZMA). For the portal screenshot's separate **Code File** upload, use the smaller standard-Deflate `RunTime_Error_code.zip`; the complete package remains available when a final package with candidate pairs is requested.

Only the **seven raw Git LFS TSVs from the supplied challenge repository** are used for identity data. Git LFS pointer text is not input data. No business identity database, Web/API lookup, external labeled dataset, geocoding or geospatial enrichment is used. All target-dependent rarity sketches derive from the provided S2/S3 TSVs. The test set has no ground truth; **no leaderboard or France F-score is claimed**. The learned binary model is LightGBM 4.6.0 (MIT), trained from scratch with 430 small trees and 56 non-ID features; far fewer than 8B parameters. See `Documentation_template.md` for algorithm, split and limitations.

## Environment and folder layout

Python 3.13 (Linux x86-64); see `requirements.txt` for exact versions. RAM ~2 GiB minimum; generous temporary disk (~15 GiB) recommended. The optimizer and SQL engine use up to 2 worker threads. Install with:

```sh
python3 -m pip install -r code/business_entity_resolution/requirements.txt
```

Make the following directories with **real data pulled via Git LFS**, using the repository specified by the challenge (data files are not repackaged):

```text
/path/to/dataset/train/train_source1.tsv
/path/to/dataset/train/train_source2.tsv
/path/to/dataset/train/train_source3.tsv
/path/to/dataset/train/train_ground_truth.tsv
/path/to/dataset/test/test_source1.tsv
/path/to/dataset/test/test_source2.tsv
/path/to/dataset/test/test_source3.tsv
```

For example, clone the provided repository with Git LFS enabled; verify that `train_source1.tsv` starts with `entity_id<TAB>business_name` rather than `version https://git-lfs...`. Check the supplied repository's own LFS SHA-256 pointers if sourcing LFS objects manually. Do not fetch third-party entity records.

## Reproduce frozen test inference

From the unzipped submission root (no inputs needed beyond the organizer's raw challenge data):

```sh
python3 code/business_entity_resolution/src/run_pipeline.py \
  --mode predict --data-dir /path/to/dataset \
  --work-dir /path/to/large/scratch \
  --output-dir /path/to/reproduced/output
```

The included `model.txt` + `model.json` specify the trained weights, feature ordering, threshold **0.66**, and top-K **10**. Internally this command (a) checks input headers and cleans records, (b) constructs 9 keyed retrieval channels, (c) scores a bounded 160-pair retrieval pool with text similarity, (d) selects the exact 10 pairs to score, (e) applies the saved binary LightGBM, (f) writes both TSVs, and (g) checks every ID and row against the actual source TSVs. Countries are independent keys, not a training-only whitelist; French records remain eligible for retrieval and prediction.

Restart the same command if interrupted. Disk-backed posting/Parquet stages, 25k-query blocking partitions, 50k-query inference chunks and final output assembly are restartable. Output ordering is the raw test S1 row order; IDs in each list are sorted for deterministic diffs and stronger compression. Expect multi-hour processing on a 2 GiB single machine: ~10M targets, ~1.73M references, ~200M hashed postings and many millions of evaluated pairs. Scratch data are excluded from the archive.

## Full retraining / held-out evaluation

```sh
python3 code/business_entity_resolution/src/run_pipeline.py \
  --mode all --data-dir /path/to/dataset \
  --work-dir /path/to/large/scratch \
  --output-dir /path/to/reproduced/output
```

`--mode all` re-fits the model before running test inference and writes development and locked holdout reports. Training S1 is selected deterministically by `xxh3_64(entity_id) % 1000`: `[0,25)` fit, `[25,33)` development, `[33,45)` locked holdout. All provided train S2/S3 records are available as **unlabeled** retrieval targets; labels are taken only from `train_ground_truth.tsv`. Model threshold is optimized for per-S1 **macro F0.5**, including singleton S1 entities (correct empty prediction scores 1). The selected decision rule was frozen before one-time holdout evaluation. No test labels exist. To train separately, inspect `src/train_model.py` and `src/holdout_evaluate.py`.

Convenient per-stage commands, with `ROOT` pointing to the unzipped submission and `DATA` to the challenge data:

```sh
python3 "$ROOT/code/business_entity_resolution/src/prepare.py" --data-dir "$DATA" --work-dir "$WORK" --split test --role both
python3 "$ROOT/code/business_entity_resolution/src/augment_keys.py" --work-dir "$WORK" --split test --role both
python3 "$ROOT/code/business_entity_resolution/src/idf_augment.py" --work-dir "$WORK" --split test --role both
python3 "$ROOT/code/business_entity_resolution/src/candidates.py" --work-dir "$WORK" --split test --topk 160 --prelimit 100 --partition-raw
python3 "$ROOT/code/business_entity_resolution/src/rerank.py" --work-dir "$WORK" --split test --topk 10
python3 "$ROOT/code/business_entity_resolution/src/infer.py" --work "$WORK/test" --model "$ROOT/code/business_entity_resolution/model.txt" --config "$ROOT/code/business_entity_resolution/model.json" --output-dir "$OUT"
python3 "$ROOT/code/business_entity_resolution/src/validate_streaming.py" --data-dir "$DATA" --output-dir "$OUT" --report "$ROOT/reports/reproduced_validation.json" --max-candidates 10
```

**Do not** lower `--topk` in the *blocking-pool* command: its 160 is an initial recall pool; the later 10 is the final model-scored shortlist. For scripts in `src`, standard Python invocation automatically sets module lookup to their directory. To resume inference after a partial run, run the same `infer.py` command again; a complete chunk is atomically renamed from `.part`. Deleting a chunk pair causes that chunk to be recomputed.

## Quality assurance and known limitations

`src/validate_streaming.py` validates the exact two headers, matching source-1 row order/completeness/uniqueness, per-list uniqueness and max K, `matches ⊆ candidates`, exact target ID existence via temporary disk-backed bitmaps read from **all test S2/S3 records**, and hashes both outputs. It is stricter than a format-only check. On machines with ample RAM, you may *also* run the organizer's official full two-file validator. Reported holdout macro F0.5 is a local estimate only, not an official score; France is unseen in labeled train, and its score is unknown. Incorrect/absent addresses, transliteration variants, same-address businesses and retrieval truncation are expected error sources.

The package uses the GPL-licensed Unidecode *generic transliteration library* for text normalization; it supplies no business facts and is **not the final model**. Inspect dependency licensing for your deployment obligations. LightGBM's fitted model library is MIT. DuckDB, RapidFuzz and PyArrow use permissive licenses.
