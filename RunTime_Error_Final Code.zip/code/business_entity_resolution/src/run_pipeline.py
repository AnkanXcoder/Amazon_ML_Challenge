"""One-command reconstruction from real challenge data; restartable heavy stages.

Run from any directory; --work-dir needs several GB, --data-dir must contain
train/{train_source1..3.tsv,train_ground_truth.tsv} and test/test_source1..3.tsv.
No internet/network request or external identity database occurs in this code.
"""
from __future__ import annotations
import argparse,logging
from pathlib import Path
from prepare import main as _unused,validate_input
from augment_keys import main as _unused2
from candidates import build_bucket,merge_buckets,BUCKETS
from rerank import score_pool,select_top
from idf_augment import target_frequency,augment as add_idf
from augment_keys import augment as add_composites
from prepare import write_records
from infer import infer,assemble
from train_model import train
from holdout_evaluate import evaluate
from validate_streaming import validate
import json,math
LOG=logging.getLogger(__name__)
def do_prepare(data:Path,root:Path,split:str,train_size:int=25,val_size:int=20):
    work=root/split;work.mkdir(parents=True,exist_ok=True)
    mf=work/'prepare_manifest.json';manifest=json.loads(mf.read_text()) if mf.exists() else {}
    for role in ('targets','queries'):
        keys=work/f'{role}_keys';rec=work/f'{role}_records.parquet'
        if rec.is_file() and all((keys/f'key_{j:02d}.parquet').is_file() for j in range(BUCKETS)):
            if manifest.get('train_size')==train_size and manifest.get('val_size')==val_size and manifest.get('max_per_file') is None and role in manifest:
                LOG.info('Reuse prepared %s %s',split,role);continue
        manifest[role]=write_records(split,data,work,role,train_size,val_size,None)
    manifest.update(split=split,train_size=train_size,val_size=val_size,max_per_file=None)
    mf.write_text(json.dumps(manifest,indent=2))
    return work
def do_keys(w:Path):
    for role in ('targets','queries'):
        if not all((w/f'{role}_keys/key_{b:02d}_extra.parquet').is_file() for b in range(BUCKETS)):add_composites(w,role)
    freq=None
    for role in ('targets','queries'):
        if not all((w/f'{role}_keys/key_{b:02d}_idf.parquet').is_file() for b in range(BUCKETS)):
            if freq is None:freq=target_frequency(w)
            add_idf(w,role,freq)
def do_retrieval(w:Path,topk:int=40):
    partition=json.loads((w/'prepare_manifest.json').read_text())['queries']['records']>150000
    for b in range(BUCKETS):
        complete=w/'bucket_pairs'/f'bucket_{b:02d}'/'.complete' if partition else w/'bucket_pairs'/f'bucket_{b:02d}.parquet'
        if not complete.exists():build_bucket(w,b,prelimit=100,partition_raw=partition)
    pool=w/'retrieval_pool.parquet';cand=w/'candidates.parquet'
    if not pool.is_file():
        merge_buckets(w,topk=160,partition_raw=partition)
        cand.rename(pool)
    if not (w/'pool_scored.parquet').exists() and not (w/'pool_scored_shards/.complete').exists():
        assert score_pool(w)
    # choose top 40 for fitting, top frozen K for test; never use test ground truth
    if not cand.is_file():select_top(w,topk)
def run(a):
    for split in (('train','test') if a.mode=='all' else ('test',)):
        LOG.info('Pipeline %s',split);work=do_prepare(a.data_dir,a.work_dir,split)
        do_keys(work);do_retrieval(work,40 if split=='train' else a.topk)
        if split=='train':
            truth=a.data_dir/'train'/'train_ground_truth.tsv';validate_input(truth,'source1_entity_id\tmatched_entity_ids')
            summary=train(work,truth,a.model,a.reports/'development_metrics.json')
            assert int(summary['topk_default'])==a.topk,'Frozen K differs from train config; change --topk or train_model config'
            evaluate(work,truth,a.model,a.model.with_suffix('.json'),a.reports/'locked_holdout_metrics.json')
        else:
            if not a.model.exists():raise FileNotFoundError('Model not found; run --mode all or use included frozen model')
            if not infer(work,a.model,a.model.with_suffix('.json'),a.chunk_size,None):raise RuntimeError('Inference incomplete; rerun')
            assemble(work,a.output_dir,a.chunk_size)
            validate(a.data_dir,a.output_dir,a.reports/'full_submission_validation.json',a.topk)
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['predict','all'],default='predict')
    p.add_argument('--data-dir',required=True,type=Path,help='Root containing unmodified train/ and test/ Git LFS TSVs')
    p.add_argument('--work-dir',required=True,type=Path,help='Scratch/index folder, outside final zip')
    p.add_argument('--output-dir',required=True,type=Path)
    p.add_argument('--model',type=Path,default=Path(__file__).resolve().parents[1]/'model.txt')
    p.add_argument('--reports',type=Path,default=Path(__file__).resolve().parents[3]/'reports')
    p.add_argument('--topk',type=int,default=10);p.add_argument('--chunk-size',type=int,default=50000)
    args=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    run(args)
