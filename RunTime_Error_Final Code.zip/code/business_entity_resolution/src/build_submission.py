"""Build & re-check the RunTime Error self-contained LZMA submission ZIP.

From any directory: python3 code/business_entity_resolution/src/build_submission.py
The source folder must contain BOTH complete output TSVs. If an extracted archive
was edited, use this same command to repackage it before portal submission.
"""
from __future__ import annotations
import argparse,hashlib,json,os,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
REQUIRED=('output/matching_results.tsv','output/candidate_pairs.tsv',
          'code/business_entity_resolution/README.md','code/business_entity_resolution/requirements.txt',
          'code/business_entity_resolution/model.txt','code/business_entity_resolution/model.json',
          'Documentation_template.md','বাংলা_প্রজেক্ট_গাইড.md',
          'RunTime_Error_আপলোড_নির্দেশনা.md')
def hexdigest(stream):
    h=hashlib.sha256()
    for b in iter(lambda:stream.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def package(dest:Path,max_mib:int):
    root=ROOT;files=[root/f for f in REQUIRED]
    files+=sorted((root/'code/business_entity_resolution/src').glob('*.py'))
    files+=sorted((root/'reports').glob('*.json'))
    for x in files:
        if not x.is_file() or x.is_symlink():raise ValueError(f'Missing or symlinked submission file: {x}')
    assert len(files)==len(set(files))
    report=json.loads((root/'reports/full_submission_validation.json').read_text())
    if report['status']!='PASS' or report['maximum_candidates_per_source1']!=10:
        raise ValueError('No matching validated full two-file K=10 report; run validate_streaming.py')
    for name,expected in report['sha256'].items():
        with (root/'output'/name).open('rb') as f:
            found=hexdigest(f)
        if found!=expected:raise ValueError(f'{name} no longer matches full validation hash; revalidate outputs')
    dest=dest.resolve();dest.parent.mkdir(parents=True,exist_ok=True);tmp=dest.with_suffix('.partial.zip')
    if tmp.exists():tmp.unlink()
    begin=time.time()
    try:
        with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_LZMA,allowZip64=True) as z:
            for file in files:
                entry=file.relative_to(root).as_posix()
                z.write(file,entry)
                print(f'Packed {entry}: {file.stat().st_size:,} bytes',flush=True)
        size=tmp.stat().st_size
        if size>max_mib*1048576:raise ValueError(f'Archive {size/1048576:.2f} MiB exceeds {max_mib} MiB; keep validated smaller candidate cap')
        with zipfile.ZipFile(tmp) as z:
            if z.testzip() is not None:raise ValueError('Corrupt ZIP member')
            names=set(z.namelist());assert names=={f.relative_to(root).as_posix() for f in files}
            for name,expected in report['sha256'].items():
                with z.open('output/'+name) as stream:
                    if hexdigest(stream)!=expected:raise ValueError(f'Archive content mismatch in {name}')
        tmp.replace(dest)
        with dest.open('rb') as f:digest=hexdigest(f)
        print(f'VERIFIED: {dest} {size:,} bytes ({size/1048576:.2f} MiB), SHA-256 {digest}, elapsed {time.time()-begin:.1f}s')
        return {'archive':str(dest),'bytes':size,'sha256':digest,'members':len(files)}
    finally:
        if tmp.exists():tmp.unlink()
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dest',type=Path,default=ROOT.parent/'RunTime_Error_submission.zip')
    p.add_argument('--max-mib',type=int,default=126)
    a=p.parse_args();package(a.dest,a.max_mib)
