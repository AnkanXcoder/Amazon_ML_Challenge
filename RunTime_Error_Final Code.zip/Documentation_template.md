# ML Challenge 2026 · Business Entity Resolution — Solution Methodology

**Team Name:** RunTime Error  
**Team Members:** ANKAN SEN (Team Leader); Subhadip Bera; Nilanjan Nayak; Sudam Mahato  
**Submission Date:** 2026-09-26  
**Source:** Organizer-supplied Git LFS train/test TSVs in `AnkanXcoder/Amazon_ML_Challenge`; no outside business-identity data.

> **Evaluation boundary.** All F₀.₅, precision, recall and error counts below refer exclusively to held-out *labeled training* entities. The challenge's **test labels are not provided**. No France/test F₀.₅ or leaderboard score is asserted. Values were measured on the final shipped **top-10**, 0.66-threshold model and outputs, not on an earlier top-16 experiment.

---

## 1. Executive Summary

We developed an open-country, bounded-memory hybrid entity resolver: **country-scoped, nine-channel frequency-capped blocking → rare address-composite augmentation → lightweight text-rerank of a 160-candidate retrieval pool → scratch-trained MIT LightGBM pair classifier**. Its unusually useful address branch joins *house number + uncommon address term* and *pairs of rare address terms*, making it less dependent on exact registered names while retaining name-only fallback when the target address is missing. Predictions can contain zero, one or many S2/S3 entities per S1. The frozen **K=10, threshold=0.66** rule reached **0.943869 development** and **0.942229 locked-holdout per-entity macro F₀.₅**; no test-score assertion is possible. The smaller cap is an explicit, measured artifact-size trade-off rather than a claim that top-10 is the unconstrained accuracy optimum.

---

## 2. Methodology

### 2.1 Input provenance, problem analysis and empirical audit

Only original organizer Git LFS files were used. The seven object hashes were checked against the Git LFS pointer SHA-256 entries when obtaining the data. The parser refuses Git LFS pointer text, checks exact source TSV headers, preserves comma-containing addresses as **single tab-delimited fields**, and never joins a third-party identifier service. All reported statistics are derived from the organizer's raw data. The provided test set has France entities, but the labeled training set has only US/India.

| Supplied split/source | Records | Salient observation |
|:--|--:|:--|
| Train S1 | 2,206,821 | US 1,323,633; India 883,188. |
| Train S2 | 5,034,616 | 168,967 records have missing addresses. |
| Train S3 | 5,285,603 | 175,916 records have missing addresses. |
| Train S1→targets truth | 2,206,821 S1, 7,638,365 links | 123,247 S1 singletons. The full task is multi-label, not just pair classification. |
| Test S1 | **1,732,544** | US 663,106; India 809,986; unseen **France 259,452**. |
| Test S2 + S3 | **9,969,589** | India 4,717,565; US 3,817,031; France 1,434,993. |

The raw-data audit also found non-ASCII names, especially in India S2/S3 and France, abbreviations and noisy street/house numbers, alternate scripts/transliterations, and trade versus legal names. In a deterministic small labeled diagnostic sample (`reports/eda_summary.json`), 14.77% of matched names had *zero* exact shared name tokens and 7.89% had low name token-set similarity (<0.5). These sample figures are diagnostics, not population-wide performance claims. Exact-name-only blocking therefore has a severe false-negative ceiling. Missing target addresses prevent an address-only key from being sufficient. Identically named or co-located firms threaten precision, particularly when the challenge rewards singleton correctness.

### 2.2 Strategy and distinctive design

1. **Clean without leakage:** create normalized *names, legal-light name cores, addresses, digit strings, informative address tokens and coarse region tokens*. Lowercase/normalize Unicode; generic transliteration uses only algorithmic Unicode conversion, not a business lookup; legal suffixes/address boilerplate are removed from selected features but original normalized text is retained too. Query ID is used only for deterministic train split and output indexing; **numeric IDs are not classifier features**.
2. **Join only plausible pairs:** compute independently keyed postings for names, phonetic skeletons, addresses and numerically anchored address composites. Sketch address-term rarity from a deterministic 1% sample of *the current split's provided target rows*; no external corpus. Keys are hashed with `(country, key)` and bucketed to avoid cross-country collisions while accepting any country string, including France. Frequency ceilings stop common words from exploding the join.
3. **Two-stage ranking:** combine per-key inverse-log frequency evidence, cap initial pool at **160** per S1, enrich with five text-similarity measures and rerank before applying the final **10**-pair ML candidate cap. Every `candidate_pairs.tsv` ID is **exactly** one of the final rows sent to the fitted LightGBM. No matched ID is injected after candidate generation.
4. **Multi-label, singleton-aware scoring:** independently threshold each pair's probability at **0.66**; an S1 with no passing pairs remains an empty list. Select threshold by actual per-S1 macro F₀.₅ on development, not by optimizing pair AUC or micro F₁. Leave holdout sealed until the inference rule is fixed.

### 2.3 Normalization / open-set countries

`src/normalization.py` performs NFKC/Unidecode transliteration for non-ASCII strings, lowercasing, a fixed abbreviation map, legal-designator-light name core, retained full normalized names, and tokenized addresses. It extracts digit sequences and conservative region tokens; a phonetic-ish consonant skeleton tolerates certain Latin spelling and transliteration substitutions (`ph→f`, `w→v`, `c/q→k`, adjacent repeats). Generic legal/road tokens are ignored only for appropriate comparison keys; no target attributes are silently discarded. `country.casefold()` feeds the hash of the record and key; code **never enumerates an allowed country list**. French queries and French targets share hashes. No labeled French match is invented, no France-specific threshold is fitted.

---

## 3. Candidate Generation (Blocking)

### 3.1 Nine complementary key channels

| Kind | Key contents | Rationale |
|:--|:--|:--|
| `e` | Entire legal-light name core | Very selective exact match. |
| `n` | Long informative name terms | Partial/renamed business fallback. |
| `p` | First four characters of long name words | Prefix errors and orthographic drift. |
| `s` | Consonant skeleton of long name words | Transliteration/spelling tolerance. |
| `a` | Long non-generic address words | Match when name is changed. |
| `h` | House number plus one region word | Strong street/house anchor. |
| `b` | Two long name terms | Selective legal/trade-name pair. |
| `d` | Two address terms, including rarity-selected pairs | Street/city association even without full name. |
| `v` | Address number plus address term, including rarity-selected pairs | Address-number co-occurrence with a term. |

For composite `d/v`, ordinary keys use the longest available source terms; additional keys select a few low-frequency terms from a target-only 1%-sampling sketch. Candidate weight per key is proportional to its kind-specific importance divided by `ln(target_key_frequency+2)`. Kind-dependent frequency caps range from 90 to 1,000 target posting entries (`src/candidates.py`). Rejecting extremely common keys is a memory and precision safeguard; useful rare keys remain. Deduplicate each S1–target pair, aggregate support and per-kind hit counts, keep up to **100 pairs per key bucket**, then retain top **160** across 16 external-memory hash buckets. On full test: **250,146,097** pooled pairs. Operations are partitioned into 25,000-query shards, Parquet postings and disk-spilling DuckDB SQL, so an unsharded multi-billion comparison is never materialized.

For the 160-pair pool, compute name Jaro-Winkler and Jaccard, address Jaccard and containment, shared-number flag; rank with `1.1·ln(1+support) + 1.5·name_jaro + 0.6·name_jaccard + 1.1·address_jaccard + 1.2·address_containment + 0.35·number_overlap`, breaking ties reproducibly by support and target index. During local fitting, take top **40** so development can compare caps; during test, take the frozen top **10** (model-scored). This generated **17,297,222** test pair records. The 53 S1 with *no* candidate are still present with empty candidate and match lists.

**Selection trade-off:** On labeled development, top-16 reached 0.946020 macro F₀.₅ versus 0.943869 for top-10, while top-8 reached 0.942325. The 10-pair cap sacrifices ~0.002151 measured development points to keep both full TSVs plus code/model inside the persistent ~128 MiB compressed-package limit. A preliminary 50k-query compression sample estimated ~84 MiB for top-10 candidates and ~33 MiB for predicted matches; the final archive size is verified separately when built. The 10-pair choice was made from development/compression **before** inspecting holdout; the latter was not used to tune the rule. Retrieval recall on unlabeled test is unknown by definition.

---

## 4. Matching Model

**Architecture/license:** LightGBM 4.6.0 MIT-licensed binary gradient-boosted decision trees, trained from scratch with no pretrained embeddings/weights. Fixed seed 2026, at most 47 leaves/tree, learning rate 0.065, max_bin 127, min_data_in_leaf 95, L2 penalty 4.0, feature/bagging fractions 0.88/0.82, 2 CPU threads. AUC-based early stopping with a maximum of 430 iterations retained **430 trees**. Roughly 430×47 leaf scores plus splits are *orders of magnitude* below 8 billion parameters. The frozen weights are `code/business_entity_resolution/model.txt` with `model.json` specifying feature order, **K=10** and **0.66**. The actual final classifier, not merely the SQL rerank, scores every submitted candidate pair.

**56 numeric pair features** (`src/features.py`):

- Multiple full/core/skeleton name character and token ratios; legal-light normalized ratios, token-set/sort/partial fuzzy match, WRatio, exact token intersections, two directional best-word fuzzy measures.
- Full address fuzzy ratios, token intersection/containment/Jaccard, best-word fuzzy measures, address presence/length balance.
- Shared address-number count, first-number equality and mutually exclusive one-number conflict; longest shared number, address-region agreement. These are *address strings*, not target-ID digits.
- S2/S3 provenance indicator, match-support log, text-rerank rank, five cheap SQL name/address/number measures and nine per-kind key-hit counts. Country affects compatible blocking but is not a model-country whitelist.

**Train/evaluate boundary:** The XXH3 hash of each *training S1 ID* modulo 1,000 places `[0,25)` in fit (**54,948 S1**), `[25,33)` in development (**17,874**), `[33,45)` in locked holdout (**26,711**). The held-out S1s never enter fitting. All **10,320,219 training S2/S3** are used *as unlabeled retrieval targets* in every split, so lookalike cross-query negatives are realistic; true S1→target labels only annotate the fit fold. In training, keep all true-positive candidate pairs plus top-16 hard negatives and a reproducible 1-in-6 sample of lower-ranked negatives. Result: **1,089,976 fit pairs**, including **179,545 positives**; development scores all **700,965** top-40 pairs, of which **58,751** are in ground truth. The holdout was evaluated just once after selection. The model is saved; test uses saved weights, never train/test truth leakage.

**Exact metric and threshold search:** For each S1 with TP, FP, FN, `F₀.₅ = 1.25·TP/(1.25·TP + FP + 0.25·FN)`; if both ground truth and predictions are empty assign **1**, and if truth is empty but predictions exist assign **0**. Average across **all S1**, not merely matched pairs, and search a grid of probabilities on development for K ∈ {8,10,11,12,16,20,24,32,40}. The unconstrained best K=16 was not shippable under the available package-size budget. Freeze **K=10, probability ≥0.66** for every country; no group-level/post-hoc match additions. Group singleton score is counted at every threshold.

---

## 5. Results and Error Analysis

| **Labeled training-derived evaluation only** | S1 | Macro F₀.₅ | Micro link precision | Micro link recall | K |
|:--|--:|--:|--:|--:|--:|
| Development, used to choose probability and feasible K | 17,874 | **0.943869** | 0.982602 | 0.881696 | 10 |
| Locked holdout, evaluated once with frozen rule | 26,711 | **0.942229** | **0.982311** | **0.881745** | 10 |

The locked holdout contains **1,514 singleton S1**, with **1,391** correctly predicted empty (91.8758%). Country scores: US **0.956910**, India **0.920555**. Of **92,267** known links, **84,965** were retrievable at the final K=10 (candidate link recall **0.920860**); **81,356** were selected, out of **82,821** predictions. Thus **7,302** true links never entered final candidates, **3,609** candidate true links were rejected by the model, and **1,465** predictions were false positives. These are counts **only in holdout**, not test. K=10 makes retrieval truncation a material error source. Common difficult cases include different writing scripts/transliteration, a legal name versus local brand, conflicting or missing street numbers, and businesses sharing a building or name; conservative thresholds reduce false merges but miss some ambiguous matches. Improving generalization would require better within-dataset cross-script blocking and carefully validated address understanding, *not* external lookup.

**Unlabeled test audit, no test accuracy claim:**

| Coverage / output check | Measured value |
|:--|--:|
| Test S1 rows in *each* output TSV | **1,732,544** |
| French S1 included | **259,452** |
| Submitted model-scored candidate links | **17,297,222** |
| Predicted S2/S3 links | **5,425,972** |
| Empty predicted match lists | **108,275** |
| Candidate links by S1 country | US 6,608,246; France 2,593,357; India 8,095,619 |
| Predicted links by S1 country | US 2,146,057; France 860,249; India 2,419,666 |

These link counts are not true-positive numbers. `reports/full_submission_validation.json` records an **exact full test-ID and format PASS** from `src/validate_streaming.py`: it compares every S1 row against source1 in order, verifies every candidate in the supplied S2/S3 with disk-backed exact-ID bitmaps (9,969,589 distinct target IDs read), checks list uniqueness and `matches ⊆ scored candidates`, including France, and hashes both TSVs. The organizer's original validator also returned **PASS for the entire matching_results.tsv alone** using its default low-memory settings; by design that run warned it skipped optional candidate/ID checks. We did **not** claim a two-file PASS from the organizer's memory-hungry implementation; the stronger streaming validation independently checked *both* files and *all* exact supplied target IDs. A team with ample RAM can rerun the organizer's two-file validator before portal submission.

**Generalization limit:** France is deliberately absent from labeled train. Open-country indexing enables French predictions and output completeness; it cannot establish French precision, recall or leaderboard standing. Country-name normalization only casefolds the provided country string; unseen spellings of a country would require additional self-contained handling. A candidate cap and frequency ceilings cannot recover every match when names and addresses have no reliable shared terms. This is a transparent local holdout estimate, not an official score.

---

## 6. Conclusion

A multi-channel, rarity-aware index plus text rerank and a compact, scratch-trained MIT LightGBM makes 10M-target resolution tractable without any external business data. The frozen, singleton-aware K=10 rule scored **0.942229** on labeled locked holdout while respecting the deliverable-size budget. Both complete test TSVs were generated and validated; no test/French accuracy is knowable without organizer labels.

---

## Appendix A · Reproducibility and artifacts

```text
output/matching_results.tsv                      # leaderboard file
output/candidate_pairs.tsv                       # EXACT final ML-scored candidate set
code/business_entity_resolution/README.md         # installation / stage-by-stage / resume instructions
code/business_entity_resolution/requirements.txt   # pinned Python dependencies
code/business_entity_resolution/src/*.py           # complete runnable pipeline
code/business_entity_resolution/model.txt          # frozen fitted LightGBM trees
code/business_entity_resolution/model.json         # threshold / cap / feature order
Documentation_template.md                          # this filled template
reports/*.json                                     # measured development, holdout, raw-data audit, full QA
বাংলা_প্রজেক্ট_গাইড.md                              # Bengali handoff
RunTime_Error_আপলোড_নির্দেশনা.md                    # portal's two upload boxes, extraction checklist
```

From an unpacked archive with the supplied raw `train/` and `test/` Git LFS TSVs available, install requirements and run:

```sh
python3 -m pip install -r code/business_entity_resolution/requirements.txt
python3 code/business_entity_resolution/src/run_pipeline.py --mode predict \
  --data-dir /path/to/organizer_data --work-dir /path/to/large_scratch \
  --output-dir /path/to/recreated_output
```

`--mode all` first retrains on the labeled train subset and reevaluates the locked train holdout. Python 3.13/Linux with ~2 GiB RAM and generous scratch disk is the measured environment; batch stages are partitioned and restartable. The repo's raw TSVs and scratch Parquet/posting files are not distributed in the archive. The uploaded leaderboard TSV should be the **same file** as `output/matching_results.tsv` inside the zip. Team and member names above were transcribed from the participant's portal screenshot; please verify their spelling before upload. Personal phone numbers were intentionally excluded. The participant's upload screen has separate TSV and code-ZIP boxes: extract `output/matching_results.tsv` from the full `RunTime_Error_submission.zip` using Python's `zipfile` or 7-Zip (the size-bounded complete archive uses ZIP-LZMA, not supported by many default `unzip`/Windows extractors); use the standard-Deflate `RunTime_Error_code.zip` in the code-only box. The complete archive remains available for any subsequent **full final-package** requirement, because the small code-only ZIP does not contain `candidate_pairs.tsv`. Archive submission is a separate portal action requiring the user's own credentials; nothing is automatically uploaded by this code.

## Appendix B · Licensing, integrity and hashes

The **final model** library is LightGBM 4.6.0, MIT, trained entirely from the challenge labels. DuckDB (MIT), RapidFuzz (MIT) and PyArrow (Apache-2.0) support bounded computation. Unidecode is a **GPL-licensed generic transliteration dependency** and provides no identity information; teams must check its distribution obligations for their submission. No external business dataset, registration registry, geocoder, pretrained business encoder, internet identity augmentation or third-party entity-resolution API is used. The final model is not an 8B-parameter model.

SHA-256 of the fully validated output files, *before team edits*: `matching_results.tsv` **`15fde0441dc1e952927417151f0caffab75bc3ea8879ac1bacd48f429c1480bc`**; `candidate_pairs.tsv` **`97b3d127768e872ceed2f7b614483c1be56e397a93da41fafacebd39370e4f22`**. Recomputed output should be revalidated if the environment or model changes. These hashes identify the exact files packaged, not a test label or official evaluation result.
