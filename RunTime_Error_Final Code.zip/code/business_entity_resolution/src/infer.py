"""Restartable inference: candidate_pairs TSV is EXACT top-K scored by the model."""
from __future__ import annotations
import argparse,csv,json,logging,math,time
from collections import defaultdict
from itertools import zip_longest
from pathlib import Path
import duckdb,numpy as np,pyarrow.parquet as pq,lightgbm as lgb
from join_pairs import attach
from features import FEATURE_NAMES,feature_row
LOG=logging.getLogger(__name__);CHUNK_SIZE=50000
def query_count(work:Path)->int:return json.loads((work/'prepare_manifest.json').read_text())['queries']['records']
def get_query_ids(work:Path,start:int,end:int):
    con=duckdb.connect();z=con.execute('SELECT idx,entity_id FROM read_parquet(?) WHERE idx>=? AND idx<? ORDER BY idx',[str(work/'queries_records.parquet'),start,end]).fetchall();con.close()
    assert len(z)==end-start and all(idx==start+j for j,(idx,_) in enumerate(z));return z
def chunk_paths(work:Path,s:int):
    d=work/'output_chunks';d.mkdir(exist_ok=True)
    return d/f'candidate_{s:04d}.tsv',d/f'matching_{s:04d}.tsv'
def predict_chunk(work:Path,model:lgb.Booster,threshold:float,topk:int,start:int,end:int,num:int):
    ca,ma=chunk_paths(work,num)
    if ca.is_file() and ma.is_file():LOG.info('Reuse chunk %d',num);return
    begin=time.time();joined=work/f'chunk_joined_{num:04d}.parquet'
    if joined.exists():joined.unlink()
    npairs=attach(work,start,end,joined);cand=defaultdict(list);matches=defaultdict(list);scored=links=0
    for b in pq.ParquetFile(joined).iter_batches(batch_size=10000):
        z=b.to_pydict();fields=list(z);X=np.empty((b.num_rows,len(FEATURE_NAMES)),dtype=np.float32);info=[]
        for i,v in enumerate(zip(*(z[f] for f in fields))):
            r=dict(zip(fields,v));assert 1<=r['rnk']<=topk
            assert r['tid'].startswith(('S2-','S3-'))
            X[i]=feature_row(r);info.append((r['qidx'],r['rnk'],r['tid']))
        pp=model.predict(X,num_threads=2)
        for (q,rk,tid),p in zip(info,pp):
            cand[q].append(tid)
            if p>=threshold:matches[q].append(tid);links+=1
        scored+=len(info)
        if scored%200000<10000:LOG.info('Chunk %d %.2fM/%.2fM scored %.1fs',num,scored/1e6,npairs/1e6,time.time()-begin)
    assert scored==npairs
    ct=ca.with_suffix('.part');mt=ma.with_suffix('.part')
    with ct.open('w',encoding='utf-8',newline='',buffering=4*1024*1024) as cf,mt.open('w',encoding='utf-8',newline='',buffering=4*1024*1024) as mf:
        cw=csv.writer(cf,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE)
        mw=csv.writer(mf,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE)
        for idx,qid in get_query_ids(work,start,end):
            ids=sorted(cand[idx]);mids=sorted(matches[idx])
            assert len(ids)<=topk and len(ids)==len(set(ids)) and len(mids)==len(set(mids)) and set(mids)<=set(ids)
            cw.writerow([qid,','.join(ids)]);mw.writerow([qid,','.join(mids)])
    ct.replace(ca);mt.replace(ma);joined.unlink()
    LOG.info('Completed chunk %d: %d entities %d candidates %d predictions %.1fs',num,end-start,npairs,links,time.time()-begin)
def infer(work:Path,model_file:Path,config:Path,chunk_size:int,max_chunks:int|None):
    meta=json.loads(config.read_text());assert meta['feature_names']==list(FEATURE_NAMES)
    model=lgb.Booster(model_file=str(model_file));assert model.feature_name()==list(FEATURE_NAMES)
    n=query_count(work);nb=math.ceil(n/chunk_size);done=0
    for i in range(nb):
        a=i*chunk_size;b=min(n,(i+1)*chunk_size);c,m=chunk_paths(work,i)
        if c.exists() and m.exists():continue
        if max_chunks is not None and done>=max_chunks:break
        predict_chunk(work,model,float(meta['threshold']),int(meta['topk']),a,b,i);done+=1
    completed=sum(all(p.exists() for p in chunk_paths(work,i)) for i in range(nb))
    LOG.info('Completed %d/%d inference chunks',completed,nb);return completed==nb
def assemble(work:Path,outdir:Path,chunk_size:int):
    n=query_count(work);parts=[chunk_paths(work,i) for i in range(math.ceil(n/chunk_size))]
    if any(not (a.is_file() and b.is_file()) for a,b in parts):raise FileNotFoundError('Inference chunks incomplete')
    outdir.mkdir(parents=True,exist_ok=True);cpath=outdir/'candidate_pairs.tsv';mpath=outdir/'matching_results.tsv';cnt=0
    with cpath.open('w',encoding='utf-8',newline='',buffering=4*1024*1024) as cf,mpath.open('w',encoding='utf-8',newline='',buffering=4*1024*1024) as mf:
        cw=csv.writer(cf,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE);mw=csv.writer(mf,delimiter='\t',lineterminator='\n',quoting=csv.QUOTE_NONE)
        cw.writerow(['source1_entity_id','candidate_entity_ids']);mw.writerow(['source1_entity_id','matched_entity_ids'])
        for a,b in parts:
            with a.open(encoding='utf-8',newline='') as srca,b.open(encoding='utf-8',newline='') as srcb:
                for ar,br in zip_longest(csv.reader(srca,delimiter='\t'),csv.reader(srcb,delimiter='\t')):
                    assert ar is not None and br is not None and len(ar)==len(br)==2 and ar[0]==br[0]
                    cw.writerow(ar);mw.writerow(br);cnt+=1
    assert cnt==n
    LOG.info('Assembled %d S1 output rows: %s %s',n,cpath,mpath);return cpath,mpath
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work',required=True,type=Path);p.add_argument('--model',required=True,type=Path)
    p.add_argument('--config',required=True,type=Path);p.add_argument('--output-dir',required=True,type=Path)
    p.add_argument('--chunk-size',type=int,default=CHUNK_SIZE);p.add_argument('--max-chunks',type=int)
    p.add_argument('--assemble-only',action='store_true');a=p.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    if not a.assemble_only and not infer(a.work,a.model,a.config,a.chunk_size,a.max_chunks):
        print('Inference incomplete; rerun same command to resume');return
    assemble(a.work,a.output_dir,a.chunk_size)
if __name__=='__main__':main()
