"""Exact, memory-bounded, full-row test ID/subset/format audit of BOTH output TSVs.

Uses disk-backed bitmaps, not trusting a syntactically plausible S2/S3 identifier.
The S1 order check is stronger than merely checking a set of IDs: generated files
are required to follow the original input test_source1.tsv record order.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,logging,mmap,re,tempfile,time
from itertools import zip_longest
from pathlib import Path
from collections import Counter
from prepare import validate_input
LOG=logging.getLogger(__name__);MAX_ID=1_000_000_000;BITMAP_BYTES=(MAX_ID+7)//8
TARGET_RE=re.compile(r'S([23])-([0-9]{1,9})\Z')
def bits_lookup(bitmaps,tid:str)->tuple[int,int,int]:
    m=TARGET_RE.fullmatch(tid)
    if not m:raise ValueError(f'Invalid target ID: {tid!r}')
    source=int(m.group(1));num=int(m.group(2));return source,num>>3,1<<(num&7)
def initialize_bitmap(path:Path):
    with path.open('wb') as f:f.truncate(BITMAP_BYTES)
    handle=path.open('r+b');return handle,mmap.mmap(handle.fileno(),0)
def load_targets(data:Path,mm:dict)->int:
    total=0
    for source in (2,3):
        path=data/'test'/f'test_source{source}.tsv'
        validate_input(path,'entity_id\tbusiness_name\tbusiness_address\tcountry')
        with path.open(encoding='utf-8',newline='',buffering=4*1024*1024) as fp:
            for rec in csv.DictReader(fp,delimiter='\t'):
                tid=rec['entity_id'];si,byte,mask=bits_lookup(mm,tid)
                if si!=source:raise ValueError(f'{path} source prefix mismatch: {tid}')
                if mm[si][byte]&mask:raise ValueError(f'Duplicate target ID: {tid}')
                mm[si][byte]=mm[si][byte]|mask;total+=1
        LOG.info('Loaded source %d exact entity ID membership, cumulative %d',source,total)
    return total
def parse_row(row:list[str]|None,expected_id:str,header:str,lineno:int)->list[str]:
    if row is None or len(row)!=2 or row[0]!=expected_id:
        raise ValueError(f'Row {lineno} of {header}: expected {expected_id!r}, found {row!r}')
    return [] if not row[1] else row[1].split(',')
def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def validate(data:Path,out:Path,report:Path,max_candidates:int=10):
    start=time.time();mfile=out/'matching_results.tsv';cfile=out/'candidate_pairs.tsv'
    source=data/'test'/'test_source1.tsv'
    validate_input(source,'entity_id\tbusiness_name\tbusiness_address\tcountry')
    report.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ber_id_check_') as tmp:
        files={};mm={}
        try:
            for i in (2,3):files[i],mm[i]=initialize_bitmap(Path(tmp)/f'ids{i}.bitmap')
            target_count=load_targets(data,mm)
            counts=Counter();by_country=Counter();by_country_matching=Counter();by_country_empty=Counter()
            with source.open(encoding='utf-8',newline='',buffering=4*1024*1024) as s,cfile.open(encoding='utf-8',newline='',buffering=4*1024*1024) as c,mfile.open(encoding='utf-8',newline='',buffering=4*1024*1024) as m:
                qs=csv.DictReader(s,delimiter='\t');qc=csv.reader(c,delimiter='\t');qm=csv.reader(m,delimiter='\t')
                assert next(qc)==['source1_entity_id','candidate_entity_ids'],'Incorrect candidate TSV header'
                assert next(qm)==['source1_entity_id','matched_entity_ids'],'Incorrect matching TSV header'
                for lineno,(sr,cr,mr) in enumerate(zip_longest(qs,qc,qm),start=2):
                    if sr is None or cr is None or mr is None:raise ValueError(f'Unmatched row counts at row {lineno}')
                    qid=sr['entity_id'];country=sr['country'];assert qid.startswith('S1-'),qid
                    cand=parse_row(cr,qid,cfile.name,lineno);matched=parse_row(mr,qid,mfile.name,lineno)
                    if len(cand)>max_candidates:raise ValueError(f'Too many candidates for {qid}: {len(cand)}')
                    if len(set(cand))!=len(cand) or len(set(matched))!=len(matched):raise ValueError(f'Duplicate ID in lists for {qid}')
                    if not set(matched).issubset(set(cand)):raise ValueError(f'Matches are not a subset of candidates for {qid}')
                    for tid in cand:
                        si,b,mask=bits_lookup(mm,tid)
                        if not mm[si][b]&mask:raise ValueError(f'Candidate target not in supplied test TSV: {tid} for {qid}')
                    counts['source1_rows']+=1;counts['candidate_pairs']+=len(cand);counts['matched_links']+=len(matched)
                    if not matched:counts['empty_prediction']+=1;by_country_empty[country]+=1
                    by_country[country]+=1;by_country_matching[country]+=len(matched)
                    if counts['source1_rows']%200000==0:LOG.info('Checked %d exact S1 rows, %d candidates, %.1fs',counts['source1_rows'],counts['candidate_pairs'],time.time()-start)
        finally:
            for v in mm.values():v.close()
            for v in files.values():v.close()
    if not counts['source1_rows']:raise ValueError('No test S1 rows in outputs')
    result={'status':'PASS','counts':dict(counts),'source1_by_country':dict(by_country),
            'predicted_links_by_country':dict(by_country_matching),'predicted_empty_lists_by_country':dict(by_country_empty),
            'test_target_ids_checked':target_count,'test_target_check':'Exact membership in supplied S2/S3 using on-disk bitmaps',
            'matched_subset_of_exact_model_candidates':True,'one_row_per_source1_even_unseen_country':True,
            'maximum_candidates_per_source1':max_candidates,'sha256':{f.name:sha256(f) for f in [cfile,mfile]},
            'elapsed_seconds':round(time.time()-start,2)}
    report.write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps(result,indent=2,ensure_ascii=False));return result
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data-dir',required=True,type=Path)
    p.add_argument('--output-dir',required=True,type=Path);p.add_argument('--report',required=True,type=Path)
    p.add_argument('--max-candidates',type=int,default=10);a=p.parse_args()
    logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    validate(a.data_dir,a.output_dir,a.report,a.max_candidates)
