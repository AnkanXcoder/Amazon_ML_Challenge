"""External-memory hashed, frequency-capped multichannel blocking; no labels used."""
from __future__ import annotations
import argparse,json,logging,math,time
from pathlib import Path
from prepare import set_duckdb,BUCKETS,sq
LOG=logging.getLogger(__name__)
CAP={'e':300,'n':240,'p':90,'s':90,'a':180,'h':220,'b':1000,'d':500,'v':500}
WEIGHT={'e':4.,'n':2.2,'p':.9,'s':.9,'a':1.7,'h':2.2,'b':4.,'d':3.4,'v':4.6}
KIND_COLUMNS=('e','n','p','s','a','h','b','d','v');SHARD_SIZE=25000
def qs(path:Path)->str:return sq(path)
def build_bucket(work:Path,bucket:int,prelimit:int=100,partition_raw:bool=False,only_shard:int|None=None)->int:
    q=work/'queries_keys'/f'key_{bucket:02d}*.parquet';t=work/'targets_keys'/f'key_{bucket:02d}*.parquet'
    folder=work/'bucket_pairs'/f'bucket_{bucket:02d}';one=work/'bucket_pairs'/f'bucket_{bucket:02d}.parquet'
    cap='CASE c.kind '+' '.join(f"WHEN '{k}' THEN {v}" for k,v in CAP.items())+' ELSE 0 END'
    weights='CASE c.kind '+' '.join(f"WHEN '{k}' THEN {v}" for k,v in WEIGHT.items())+' ELSE 0 END'
    flags=','.join(f"SUM(CASE WHEN c.kind='{k}' THEN 1 ELSE 0 END)::SMALLINT AS hits_{k}" for k in KIND_COLUMNS)
    con=set_duckdb(work/'candidates.duckdb',work);start=time.time();LOG.info('Blocking bucket %d/%d',bucket+1,BUCKETS)
    if partition_raw:
        n=json.loads((work/'prepare_manifest.json').read_text())['queries']['records'];nshards=math.ceil(n/SHARD_SIZE)
        folder.mkdir(exist_ok=True);it=range(nshards) if only_shard is None else [only_shard]
    else:it=[0]
    for shard in it:
        if partition_raw:
            d=folder/f'qshard={shard}';d.mkdir(exist_ok=True);out=d/'part.parquet'
            if out.exists() and out.stat().st_size>0:continue
            scope=f'WHERE idx >= {shard*SHARD_SIZE} AND idx < {(shard+1)*SHARD_SIZE}'
        else:out=one;scope=''
        sql=f"""
        COPY (
          WITH q_scope AS (SELECT key,idx,kind FROM read_parquet({qs(q)}) {scope}),
          unique_q AS (SELECT DISTINCT key FROM q_scope),
          freq AS (SELECT t.key, any_value(t.kind) AS kind, COUNT(*) AS frequency FROM read_parquet({qs(t)}) t JOIN unique_q u USING(key) GROUP BY t.key),
          allowed AS (SELECT * FROM freq c WHERE frequency <= {cap}),
          pair_block AS (
            SELECT q.idx AS qidx,t.idx AS tidx,
             SUM(({weights})/LN(c.frequency+2.0))::FLOAT AS support,{flags}
            FROM q_scope q JOIN allowed c USING(key) JOIN read_parquet({qs(t)}) t USING(key)
            GROUP BY q.idx,t.idx
          ), ranked AS (SELECT *,ROW_NUMBER() OVER(PARTITION BY qidx ORDER BY support DESC,tidx) AS rnk FROM pair_block)
          SELECT qidx,tidx,support,{','.join('hits_'+k for k in KIND_COLUMNS)} FROM ranked WHERE rnk<={int(prelimit)}
        ) TO {qs(out)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)
        """
        if out.exists():out.unlink()
        partial=out.with_name(out.stem+'.partial.parquet')
        if partial.exists():partial.unlink()
        con.execute(sql.replace(qs(out),qs(partial)));partial.replace(out)
        if partition_raw and (shard%10==0 or shard==nshards-1):LOG.info('Key bucket %d query shard %d/%d %.1fs',bucket,shard+1,nshards,time.time()-start)
    source=folder/'qshard=*/*.parquet' if partition_raw else one
    count=con.execute(f'SELECT COUNT(*) FROM read_parquet({qs(source)})').fetchone()[0];con.close()
    if partition_raw and only_shard is None:(folder/'.complete').write_text(str(count))
    LOG.info('Bucket %d partial pairs %d %.1fs',bucket,count,time.time()-start);return count
def merge_buckets(work:Path,topk:int,partition_raw:bool=False)->int:
    n=json.loads((work/'prepare_manifest.json').read_text())['queries']['records'];ns=math.ceil(n/SHARD_SIZE)
    dest=work/'candidates.parquet';folder=work/'candidate_shards';folder.mkdir(exist_ok=True)
    flags=','.join(f'SUM(hits_{k})::SMALLINT AS hits_{k}' for k in KIND_COLUMNS)
    con=set_duckdb(work/'candidates.duckdb',work);begin=time.time();LOG.info('Merging top-%d in %d shards',topk,ns)
    for shard in range(ns):
        out=folder/f'shard_{shard:04d}.parquet'
        if out.exists():out.unlink()
        if partition_raw:
            source=work/'bucket_pairs'/f'bucket_*/qshard={shard}/*.parquet';where=''
        else:
            source=work/'bucket_pairs'/'*.parquet';where=f'WHERE qidx >= {shard*SHARD_SIZE} AND qidx < {min(n,(shard+1)*SHARD_SIZE)}'
        sql=f"""
        COPY (WITH merged AS (SELECT qidx,tidx,SUM(support)::FLOAT AS support,{flags}
             FROM read_parquet({qs(source)}) {where} GROUP BY qidx,tidx),
           ranked AS (SELECT *,ROW_NUMBER() OVER(PARTITION BY qidx ORDER BY support DESC,tidx) AS rnk FROM merged)
           SELECT qidx,tidx,support,{','.join('hits_'+k for k in KIND_COLUMNS)},rnk FROM ranked WHERE rnk<={int(topk)}
        ) TO {qs(out)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)
        """
        con.execute(sql)
        if shard%5==0 or shard==ns-1:LOG.info('Merged shard %d/%d %.1fs',shard+1,ns,time.time()-begin)
    if dest.exists():dest.unlink()
    con.execute(f"COPY (SELECT * FROM read_parquet({qs(folder/'*.parquet')})) TO {qs(dest)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)")
    count=con.execute(f'SELECT COUNT(*) FROM read_parquet({qs(dest)})').fetchone()[0];con.close()
    LOG.info('Final retrieval-pool pairs %d %.1fs',count,time.time()-begin);return count
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work-dir',required=True,type=Path)
    p.add_argument('--split',required=True,choices=['train','test']);p.add_argument('--topk',type=int,default=160)
    p.add_argument('--prelimit',type=int,default=100);p.add_argument('--partition-raw',action='store_true')
    p.add_argument('--only-bucket',type=int);p.add_argument('--only-query-shard',type=int)
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    w=a.work_dir/a.split
    if not (w/'targets_records.parquet').is_file() or not (w/'queries_records.parquet').is_file():p.error('Run prepare.py first')
    (w/'bucket_pairs').mkdir(exist_ok=True)
    for b in (range(BUCKETS) if a.only_bucket is None else [a.only_bucket]):
        if a.partition_raw:
            if (w/'bucket_pairs'/f'bucket_{b:02d}'/'.complete').is_file() and a.only_query_shard is None:LOG.info('Reuse bucket %d',b)
            else:build_bucket(w,b,a.prelimit,True,a.only_query_shard)
        else:
            out=w/'bucket_pairs'/f'bucket_{b:02d}.parquet'
            if out.is_file() and out.stat().st_size:LOG.info('Reuse bucket %d',b)
            else:build_bucket(w,b,a.prelimit,False)
    if a.only_bucket is None and a.only_query_shard is None:
        count=merge_buckets(w,a.topk,a.partition_raw)
        (w/'candidates_manifest.json').write_text(json.dumps({'cap':CAP,'weights':WEIGHT,'topk_pool':a.topk,'prelimit':a.prelimit,'partition_raw':a.partition_raw,'pool_pairs':count},indent=2))
        print('RETRIEVAL_POOL',count)
if __name__=='__main__':main()
