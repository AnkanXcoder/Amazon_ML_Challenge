"""Label-free text-aware retrieval-pool rerank; final top-K is EXACT ML input."""
from __future__ import annotations
import argparse,json,logging,math,time
from pathlib import Path
from prepare import set_duckdb
from candidates import qs,KIND_COLUMNS,SHARD_SIZE
LOG=logging.getLogger(__name__)
SCORE="""(1.1*LN(1.0+support)+1.5*name_jaro+0.6*name_jaccard+1.1*address_jaccard+1.2*address_token_containment+0.35*number_overlap)"""
def score_pool(work:Path,max_shards:int|None=None)->bool:
    pool=work/'retrieval_pool.parquet';assert pool.is_file(),f'Need retrieval pool {pool}'
    n=json.loads((work/'prepare_manifest.json').read_text())['queries']['records'];partition=n>150000
    destdir=work/'pool_scored_shards'
    if partition:destdir.mkdir(exist_ok=True)
    q=work/'queries_records.parquet';t=work/'targets_records.parquet';count=math.ceil(n/SHARD_SIZE) if partition else 1
    con=set_duckdb(work/'rerank.duckdb',work);start=time.time();processed=0
    for shard in range(count):
        if partition:
            d=destdir/f'qshard={shard}';d.mkdir(exist_ok=True);dest=d/'part.parquet'
            if dest.exists() and dest.stat().st_size:continue
            if max_shards is not None and processed>=max_shards:break
            scope=f'WHERE c.qidx >= {shard*SHARD_SIZE} AND c.qidx < {(shard+1)*SHARD_SIZE}'
        else:
            dest=work/'pool_scored.parquet'
            if dest.exists() and dest.stat().st_size:break
            scope=''
        sql=f"""
        COPY (SELECT c.*,
         CASE WHEN q.core IS NULL OR q.core='' OR t.core IS NULL OR t.core='' THEN 0 ELSE JARO_WINKLER_SIMILARITY(q.core,t.core) END::FLOAT AS name_jaro,
         CASE WHEN q.core IS NULL OR q.core='' OR t.core IS NULL OR t.core='' THEN 0 ELSE JACCARD(q.core,t.core) END::FLOAT AS name_jaccard,
         CASE WHEN q.addr IS NULL OR q.addr='' OR t.addr IS NULL OR t.addr='' THEN 0 ELSE JACCARD(q.addr,t.addr) END::FLOAT AS address_jaccard,
         CASE WHEN q.addr IS NULL OR q.addr='' OR t.addr IS NULL OR t.addr='' THEN 0 ELSE ARRAY_LENGTH(LIST_INTERSECT(STRING_SPLIT(q.addr,' '),STRING_SPLIT(t.addr,' ')))::FLOAT /
         GREATEST(1,LEAST(ARRAY_LENGTH(STRING_SPLIT(q.addr,' ')),ARRAY_LENGTH(STRING_SPLIT(t.addr,' ')))) END::FLOAT AS address_token_containment,
         CASE WHEN q.nums IS NULL OR q.nums='' OR t.nums IS NULL OR t.nums='' THEN 0 ELSE CAST(LIST_HAS_ANY(STRING_SPLIT(q.nums,' '),STRING_SPLIT(t.nums,' ')) AS INTEGER) END::FLOAT AS number_overlap
         FROM read_parquet({qs(pool)}) c JOIN read_parquet({qs(q)}) q ON c.qidx=q.idx
         JOIN read_parquet({qs(t)}) t ON c.tidx=t.idx {scope}
        ) TO {qs(dest)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)
        """
        if dest.exists():dest.unlink()
        tmp=dest.with_name(dest.stem+'.partial.parquet')
        if tmp.exists():tmp.unlink()
        con.execute(sql.replace(qs(dest),qs(tmp)));tmp.replace(dest);processed+=1
        if shard%5==0 or shard==count-1:LOG.info('Text feature shard %d/%d elapsed %.1fs',shard+1,count,time.time()-start)
    con.close()
    if partition:
        complete=all((destdir/f'qshard={s}'/'part.parquet').is_file() for s in range(count))
        if complete:(destdir/'.complete').write_text(str(count))
    else:complete=(work/'pool_scored.parquet').is_file()
    LOG.info('Text scoring %d new shards; complete=%s elapsed %.1fs',processed,complete,time.time()-start);return complete
def select_top(work:Path,topk:int,weights:str=SCORE)->int:
    n=json.loads((work/'prepare_manifest.json').read_text())['queries']['records'];ns=math.ceil(n/SHARD_SIZE)
    dest=work/'candidates.parquet';tmp=work/'selected_candidates.parquet';d=work/'selected_shards';d.mkdir(exist_ok=True)
    partition=(work/'pool_scored_shards').is_dir()
    if partition and not (work/'pool_scored_shards/.complete').is_file():raise RuntimeError('Not all text shards complete')
    con=set_duckdb(work/'rerank.duckdb',work);start=time.time()
    for shard in range(ns):
        out=d/f'shard_{shard:04d}.parquet'
        if out.exists():out.unlink()
        if partition:source=work/'pool_scored_shards'/f'qshard={shard}/*.parquet';where=''
        else:source=work/'pool_scored.parquet';where=f'WHERE qidx >= {shard*SHARD_SIZE} AND qidx < {(shard+1)*SHARD_SIZE}'
        sql=f"""
        COPY (WITH ranked AS (SELECT qidx,tidx,support,{','.join('hits_'+k for k in KIND_COLUMNS)},
          name_jaro,name_jaccard,address_jaccard,address_token_containment,number_overlap,
          ROW_NUMBER() OVER(PARTITION BY qidx ORDER BY {weights} DESC,support DESC,tidx) AS rnk
          FROM read_parquet({qs(source)}) {where})
          SELECT * FROM ranked WHERE rnk<={int(topk)}
        ) TO {qs(out)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)
        """
        con.execute(sql)
        if shard%10==0 or shard==ns-1:LOG.info('Selected top-%d shard %d/%d (%.1fs)',topk,shard+1,ns,time.time()-start)
    if tmp.exists():tmp.unlink()
    con.execute(f"COPY (SELECT * FROM read_parquet({qs(d/'*.parquet')})) TO {qs(tmp)} (FORMAT PARQUET,COMPRESSION ZSTD,ROW_GROUP_SIZE 100000)")
    count=con.execute(f'SELECT COUNT(*) FROM read_parquet({qs(tmp)})').fetchone()[0];con.close();tmp.replace(dest)
    LOG.info('%d EXACT pre-ML candidates after text rerank %.1fs',count,time.time()-start);return count
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work-dir',required=True,type=Path)
    p.add_argument('--split',choices=['train','test'],required=True);p.add_argument('--topk',type=int,default=10)
    p.add_argument('--max-score-shards',type=int);p.add_argument('--only-score',action='store_true');p.add_argument('--only-select',action='store_true')
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    w=a.work_dir/a.split
    if not a.only_select:
        pool=w/'retrieval_pool.parquet'
        if not pool.exists():(w/'candidates.parquet').rename(pool)
        if not (w/'pool_scored.parquet').exists() and not (w/'pool_scored_shards/.complete').exists():
            if not score_pool(w,a.max_score_shards):print('Rerank scoring incomplete; rerun to resume');return
    if not a.only_score:select_top(w,a.topk)
if __name__=='__main__':main()
