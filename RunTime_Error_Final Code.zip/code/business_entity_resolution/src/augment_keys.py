"""Unsupervised length-based name/address-pair and house-address composite keys."""
from __future__ import annotations
import argparse,json,itertools,logging
from pathlib import Path
import pyarrow.parquet as pq
from normalization import ADDR_GENERIC
from prepare import hashed,BUCKETS,convert_stage
LOG=logging.getLogger(__name__)
def composite_keys(nterms:str|None,addr:str|None,nums:str|None):
    name=tuple(dict.fromkeys((nterms or '').split()))
    name=sorted((t for t in name if len(t)>=3),key=lambda x:(-len(x),x))[:3]
    address=tuple(dict.fromkeys((addr or '').split()))
    address=sorted((t for t in address if len(t)>=3 and t.isalpha() and t not in ADDR_GENERIC),key=lambda x:(-len(x),x))[:4]
    numbers=tuple(dict.fromkeys((nums or '').split()))[:3]
    for a,b in itertools.combinations(name,2):yield 'b:'+min(a,b)+':'+max(a,b)
    for a,b in itertools.combinations(address,2):yield 'd:'+min(a,b)+':'+max(a,b)
    for n in numbers:
        if len(n)>=2:
            for a in address:yield 'v:'+n+':'+a
def augment(work:Path,role:str)->int:
    dest=work/f'{role}_keys';count=0
    handles=[(dest/f'key_{i:02d}_extra.tsv').open('w',encoding='ascii',buffering=4*1024*1024) for i in range(BUCKETS)]
    for f in handles:f.write('key\tidx\tkind\n')
    for b in pq.ParquetFile(work/f'{role}_records.parquet').iter_batches(columns=['idx','country','nterms','addr','nums'],batch_size=50000):
        z=b.to_pydict()
        for idx,c,name,addr,num in zip(z['idx'],z['country'],z['nterms'],z['addr'],z['nums']):
            for key in composite_keys(name,addr,num):
                h=hashed(c,key);handles[h%BUCKETS].write(f'{h}\t{idx}\t{key[0]}\n');count+=1
        if b.num_rows and (z['idx'][-1]+1)%1_000_000<b.num_rows:
            LOG.info('%s composite %.1fM rows %.1fM keys',role,(z['idx'][-1]+1)/1e6,count/1e6)
    for f in handles:f.close()
    for i in range(BUCKETS):convert_stage(dest,f'key_{i:02d}_extra')
    LOG.info('%s new composite keys: %d',role,count)
    return count
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work-dir',required=True,type=Path)
    p.add_argument('--split',choices=['train','test'],required=True);p.add_argument('--role',choices=['targets','queries','both'],default='both')
    a=p.parse_args();logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    w=a.work_dir/a.split;result={}
    for role in (['targets','queries'] if a.role=='both' else [a.role]):
        dest=w/f'{role}_keys'
        if all((dest/f'key_{i:02d}_extra.parquet').is_file() for i in range(BUCKETS)):
            LOG.info('Reuse complete composite keys %s',role);continue
        for f in dest.glob('key_*_extra.parquet'):f.unlink()
        result[role]=augment(w,role)
    (w/'augment_manifest.json').write_text(json.dumps(result,indent=2));print(result)
if __name__=='__main__':main()
